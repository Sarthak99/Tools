package com.supplierbooking.input;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.supplierbooking.services.Slot;
import com.supplierbooking.services.SlotManager;

@Component
public class UserInput {

	Scanner in = new Scanner(System.in);
	private String requiredDate;
	private Date requiredDateFormat;
	private int depotId;
	private int slotId;

	private List<Slot> slots;

	@Autowired
	private SlotManager slotManager;

	public void start() {
		System.out.println("Enter the DepotID for which you wish to book a slot");
		depotId = in.nextInt();
		System.out.println("Enter the date for which you wish to book a slot");
		requiredDate = in.next();
		try {
			requiredDateFormat = new SimpleDateFormat("dd/MM/yyyy").parse(requiredDate);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		slots = slotManager.getSlot(requiredDateFormat, depotId);
		System.out.println("Slot Date" + "\t\t\t" + "Number of Slots" + "\t\t" + "Depot Id");
		for (int slot = 0; slot < slots.size(); slot++) {
			System.out.println(slots.get(slot).getStartTime() + " \t" + slots.get(slot).getNoOfSlot() + "\t\t\t"
					+ slots.get(slot).getDcId());
		}
		System.out.println("Enter the slotNo which you want to wish");
		slotId = in.nextInt();
		slotManager.bookslot(slotId - 1);

	}

}
