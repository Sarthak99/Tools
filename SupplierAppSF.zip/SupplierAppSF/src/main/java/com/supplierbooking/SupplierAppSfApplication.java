package com.supplierbooking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
//import org.springframework.boot.autoconfigure.security.SecurityProperties.User;
import org.springframework.context.ConfigurableApplicationContext;
//import org.springframework.context.annotation.Bean;

import com.supplierbooking.input.UserInput;

@SpringBootApplication
public class SupplierAppSfApplication {

	public static void main(String[] args) {

		ConfigurableApplicationContext ctx = SpringApplication.run(SupplierAppSfApplication.class, args);
		UserInput userInput = (UserInput) ctx.getBean(UserInput.class);
		userInput.start();
		ctx.close();

	}

}
