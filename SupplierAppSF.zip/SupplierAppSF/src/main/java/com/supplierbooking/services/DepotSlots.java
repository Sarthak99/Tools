/*An utility class which will provide functionality to get a list of slot in a depot and book a slot in a depot*/

package com.supplierbooking.services;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.TimeUnit;

import lombok.Data;

@Data
public class DepotSlots {

	private int depotId;
	private Date requiredDate;
	private List<Slot> slots;

	// Creation of date for the static slots
	String slotDate;
	Date slotDate1;
	Date slotDate2;

	public void setDate() {
		slotDate = "25/02/2020";
		try {
			slotDate1 = new SimpleDateFormat("dd/MM/yyyy").parse(slotDate);
		} catch (ParseException e) {
			e.printStackTrace();

		}

	}

	public DepotSlots() {
		super();

	}

	public DepotSlots(int depotId, Date requiredDate) {
		super();

		// Creation of slots start
		slots = new ArrayList<Slot>();
		setDate();
		this.depotId = depotId;
		this.requiredDate = requiredDate;
		Slot slot1 = new Slot(requiredDate, 10, depotId);
		slots.add(slot1);
		slotDate2 = new Date(requiredDate.getTime() + TimeUnit.HOURS.toMillis(1));
		Slot slot2 = new Slot(slotDate2, 1, depotId);
		slots.add(slot2);
		// Slot Adds
	}

	public List<Slot> getDepotSlot() {
		return slots;
	}

	public void bookDepotSlot(int slotId) {
		// noOfSlot=slots.get(slotId).getNoOfSlot();
		try {
			System.out.println("Slot booked at\t" + slots.get(slotId).getStartTime() + "\tfor depotId\t"
					+ slots.get(slotId).getDcId() + "\n");
			slots.get(slotId).setNoOfSlot(slots.get(slotId).getNoOfSlot() - 1);
		} catch (Exception e) {
			System.out.println("wrong Slot enter");
		}

	}

}
