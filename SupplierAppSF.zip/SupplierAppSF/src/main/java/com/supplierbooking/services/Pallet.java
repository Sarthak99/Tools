package com.supplierbooking.services;

public class Pallet {
	private int noOfCases;
	private int ti;
	private int hi;
	private int noOfPallet;
	public Pallet(int noOfCases, int ti, int hi) {
		super();
		this.noOfCases = noOfCases;
		this.ti = ti;
		this.hi = hi;
	}
	public int getNoOfCases() {
		return noOfCases;
	}
	public void setNoOfCases(int noOfCases) {
		this.noOfCases = noOfCases;
	}
	public int getTi() {
		return ti;
	}
	public void setTi(int ti) {
		this.ti = ti;
	}
	public int getHi() {
		return hi;
	}
	public void setHi(int hi) {
		this.hi = hi;
	}
	public int getNoOfPallet() {
		return noOfPallet;
	}
	public void setNoOfPallet(int noOfPallet) {
		this.noOfPallet = noOfPallet;
	}
	@Override
	public String toString() {
		return "BuildPallet [noOfCases=" + noOfCases + ", ti=" + ti + ", hi=" + hi + ", noOfPallet=" + noOfPallet + "]";
	}
	
	public int buildPallet() {
		noOfPallet=(int) Math.ceil(noOfCases/ti*hi);
		
		return noOfPallet;
		
	}

}
