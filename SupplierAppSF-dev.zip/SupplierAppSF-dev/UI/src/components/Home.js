import React from 'react';

class home extends React.Component
{
    render(){
    return (
       <div>
          <h1>PO Details</h1>
           <p>Welcome to PO view page</p>
       </div>
       );
    }
}

export default home;