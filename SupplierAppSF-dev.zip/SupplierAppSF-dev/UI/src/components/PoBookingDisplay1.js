import React from "react";
import Table from "react-bootstrap/Table";
import "../stylesheets/Display_PO.css";
import PoSummary from "./PoSummary";
import ActivePoTable from "./ActivePoTable";
//import AppointmentCreation from "./AppointmentCreation";

class PoBookingDisplay1 extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      countryDetail: [],
      countryCode: "",
      depotDetail: [],
      deliveryDate: "",
      depotId: "",
      PODetail: [],
      hide: false,
      vendor_NBR: "54751",
      poList: [],
      slotDetail: [],
      slotId: "",
      apptRef: "",
      errors: {
        countryCode: "",
        depotId: "",
        deliveryDate: ""
      },
      columnsTable2: {
        ColumnNames: ["Slot Time", "Button"],
        FieldNames: ["slotTime"],
        render: ({ row }) => <button>Click Me</button>
      }
    };
    this.handleDepot = this.handleDepot.bind(this);
  }

  //This function will automatically render whenever the page is reloaded.
  componentDidMount() {
    document.title = "Supplier Appointments";
    fetch("http://localhost:8080/countrylist")
      .then(res => res.json())
      .then(async data => {
        await this.setState({ countryDetail: data });
      })
      .catch(console.log);
  }

  //This function will fetch the list of depot from couchbase based on countrycode
  handleDepot() {
    fetch("http://localhost:8080/depotlist", {
      method: "post",
      body: JSON.stringify({ countryCode: this.state.countryCode })
    })
      .then(res => res.json())
      .then(async data => {
        await this.setState({ depotDetail: data });
      })
      .catch(console.log);
  }

  //Function to display list of country as a dropdown at the time of page loading itself
  buildCtryOptions() {
    var country = [];
    for (let j = 0; j < this.state.countryDetail.length; j++) {
      country.push(
        <option key={j} value={this.state.countryDetail[j].countryCode}>
          {this.state.countryDetail[j].countryName}
        </option>
      );
    }
    country.push(<option key="" defaultValue=""></option>);
    return country;
  }

  //Function to display list of depot based on selected Country.
  buildDepotOptions() {
    var depot = [];
    for (let j = 0; j < this.state.depotDetail.length; j++) {
      depot.push(
        <option
          key={this.state.depotDetail[j].depotId}
          value={this.state.depotDetail[j].depotId}
        >
          {this.state.depotDetail[j].depotId +
            "::" +
            this.state.depotDetail[j].depotName}
        </option>
      );
    }
    depot.push(<option key="" defaultValue=""></option>);
    return depot;
  }

  //This function will set the state of countryCode based on user selection of country name.
  handleCountry = async event => {
    //alert(event.target.value);
    await this.setState({ countryCode: event.target.value });
    this.handleDepot();
  };

  //This function will set the state of depotId based on user selection of depot.
  handleDepotId = async event => {
    //alert(event.target.value);
    await this.setState({ depotId: event.target.value });
  };

  //This function will set the state of deliveryDate based on user input for date.
  handledeliveryDate = async event => {
    await this.setState({ deliveryDate: event.target.value });
  };

  //Function defined for form falidation
  handleValidation = event => {
    let errors = {};
    let formIsValid = true;
    var date_pattern = /^([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))$/;
    //depotId validation
    if (!this.state.depotId) {
      formIsValid = false;
      errors["depotId"] = "Cannot be empty";
    }
    //countrycode validation
    if (!this.state.countryCode) {
      formIsValid = false;
      errors["countryCode"] = "Cannot be empty";
    }
    //deliveryDate validation
    if (
      !this.state.deliveryDate ||
      !date_pattern.test(this.state.deliveryDate)
    ) {
      formIsValid = false;
      errors["deliveryDate"] = "Cannot be empty";
    }
    this.setState({ errors: errors });
    return formIsValid;
  };

  //This method will call when user press Fetch button
  handleSubmit = async event => {
    if (this.handleValidation()) {
      alert(
        this.state.countryCode + this.state.depotId + this.state.deliveryDate
      );
      let urlfetch =
        "http://localhost:8080/purchaseorder/vendorenumber?vendor_NBR=" +
        this.state.vendor_NBR +
        "&deliveryDate=" +
        this.state.deliveryDate +
        "&countryCode=" +
        this.state.countryCode +
        "&depotId=" +
        this.state.depotId;
      fetch(urlfetch)
        .then(res => res.json())
        .then(data => {
          this.setState({ PODetail: data });
        })
        .catch(console.log);
      setTimeout(() => {
        console.log(this.state.PODetail);
      }, 100);
      fetch("http://localhost:8080/depotId/countryCode/slotDate/", {
        method: "post",
        body: JSON.stringify({
          depotId: this.state.depotId,
          countryCode: this.state.countryCode,
          slotDate: this.state.deliveryDate
        })
      })
        .then(res => res.json())
        .then(data => {
          this.setState({ slotDetail: data });
        })
        .catch(console.log);

      setTimeout(() => {
        console.log(this.state.slotDetail);
      }, 100);
      this.setState({ hide: true });
    } else {
      alert("Please fill the required field in proper format");
    }
  };
  hanndleTest = () => {
    alert("test");
  };
  //Function to create table for Available slots.
  renderTableData() {
    console.log("inside renderTableData");
    if (this.state.slotDetail.length > 0) {
      console.log("inside renderTableData if");
      return this.state.slotDetail.map((slot, index) => {
        console.log("check" + slot + index);
        // var availableSlot = true;
        // var msgButton = "Unavailable";
        const { slotId, slotTime, noOfSlots } = slot; //destructuring
        console.log(noOfSlots);
        // if (noOfSlots > 0) {
        //   availableSlot = false;
        //   msgButton = "Book";
        // }
        return (
          <tr key={slotId}>
            <td>{slotTime}</td>
            {/* {this.hanndleTest()} */}

            <td>
              <button
                type="button"
                value={slotId + slotTime}
                onClick={this.handleFormSubmit}
              >
                Book
              </button>
            </td>
          </tr>
        );
      });
    } else {
      console.log("inside else");
      return (
        <tr>
          <td>No Slot Available</td>
        </tr>
      );
    }
  }

  // //Function to set state of slot time
  // handleSlotTime = async event => {
  //   await this.setState({ slotId: event.target.value });
  //   console.log(this.state.slotId);
  // };

  //This function used to get next Appt Ref number.
  handleapptref = async event => {
    const url = "http://localhost:8080/apptref";
    const response = await fetch(url);
    const data = await response.json();
    this.setState({ apptRef: data });
  };

  //Function on click of book button
  handleFormSubmit = async event => {
    if (this.state.poList.length === 0) alert("Select at least one PO");
    else {
      event.persist();
      var temp = event.target.value;
      var slotId = temp.substr(0, 4);
      var slotTime = temp.substr(4, 5);
      await this.setState({ slotId: slotId });
      await this.handleapptref();

      //Creation of an appointment

      //Creation of Appt detail entity
      var temp_string = [];
      for (let i = 0; i < this.state.poList.length; ++i) {
        for (let j = 0; j < this.state.poList[i].detail.length; j++) {
          var temp_obj = {
            apptLine: j + 1,
            poNbr: this.state.poList[i].poNbr,
            itemId: this.state.poList[i].detail[j].sku,
            casepack: this.state.poList[i].detail[j].packSize,
            apptdContainerQty: this.state.poList[i].detail[j]
              .orgOrderedQtyCases,
            apptdUnitQty: this.state.poList[i].detail[j].orderedQtyUnits
          };
          temp_string.push(temp_obj);
        }
      }

      //Creation of  Appointment header
      var header = {
        id:
          "APPT" +
          this.state.depotId +
          this.state.countryCode +
          this.state.apptRef,
        apptNbr: "",
        apptRef: this.state.apptRef,
        creationTs: "2020-03-19",
        apptStartTs: this.state.deliveryDate + " " + slotTime + ":00",
        apptEndTs: "",
        apptStatus: "Created",
        userId: this.state.vendor_NBR,
        countryCode: this.state.countryCode,
        depotId: this.state.depotId,
        type: "Appointment",
        apptDetailEntity: temp_string
      };
      console.log("testing detail" + JSON.stringify(header));
      await fetch("http://localhost:8080/apptcreate", {
        method: "post",
        body: JSON.stringify(header)
      }).catch(console.log);
      alert(
        "Appointment Created with AppReferenceNUmber:" +
          (await this.state.apptRef)
      );
      //Appointment creation done
      await fetch("http://localhost:8080/slotupdate", {
        method: "put",
        body: JSON.stringify({ slotId: slotId })
      }).catch(console.log);
      window.location.reload();
    }
  };

  //Getting list of Po's from ActivePoTable Component.
  handlePO = ActivePo => {
    this.setState({ poList: ActivePo });
    console.log(this.state.poList);
    console.log(ActivePo);
  };

  //Jsx start for the page
  render() {
    //Inline styling
    const mystyle = {
      color: "white",
      padding: "50px",
      fontFamily: "Arial",
      margin: "50px",
      width: "50%"
    };
    const labelstyle = {
      padding: "20px"
    };
    return (
      <div className="Slotbooking">
        <PoSummary vendor_NBR={this.state.vendor_NBR} />
        <form>
          <label style={(labelstyle, { paddingLeft: "100px" })}>
            Country:
            <select
              value={this.state.value}
              onChange={this.handleCountry}
              style={{ margin: "10px" }}
            >
              {this.buildCtryOptions()}
            </select>
          </label>
          <label style={labelstyle}>
            Tesco ship to name:
            <select
              value={this.state.value}
              onChange={this.handleDepotId}
              style={{ margin: "10px" }}
            >
              {this.buildDepotOptions()}
            </select>
          </label>
          <label style={labelstyle}>
            Booking request Date:
            <input
              type="text"
              value={this.state.deliveryDate}
              onChange={this.handledeliveryDate}
              placeholder="yyyy-mm-dd"
              style={{ margin: "10px" }}
            />
          </label>
          <button type="button" onClick={this.handleSubmit}>
            View
          </button>
        </form>
        {this.state.hide ? (
          <div>
            <form>
              <div className="rowC">
                <div style={mystyle}>
                  <h4 id="title">Purchase Order's</h4>
                  <ActivePoTable
                    vendor_NBR={this.state.vendor_NBR}
                    deliveryDate={this.state.deliveryDate}
                    countryCode={this.state.countryCode}
                    depotId={this.state.depotId}
                    onSelectPo={this.handlePO}
                  />
                </div>
                <div style={mystyle}>
                  <h4 id="title" style={{ paddingBottom: "60px" }}>
                    Available Slots
                  </h4>
                  <Table hover id="slots">
                    <thead>
                      <tr>
                        <th style={{ fontSize: "15px", fontWeight: "normal" }}>
                          Slots
                        </th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>{this.renderTableData()}</tbody>
                  </Table>
                </div>
              </div>
            </form>
          </div>
        ) : null}
      </div>
    );
  }
}
export default PoBookingDisplay1;
