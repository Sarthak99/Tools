import React from "react";
import "../App.css";

class Slotbooking extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      countryDetail: [],
      countryCode: "",
      depotDetail: [],
      slotDate: "",
      depotId: "",
      slotDetail: [],
      slotId: "",
      hide: false,
      errors: {
        countryCode: "",
        depotId: "",
        slotDate: ""
      }
    };
    this.handleDepot = this.handleDepot.bind(this);
  }
  componentDidMount() {
    document.title = "Supplier Appointments";
    fetch("http://localhost:8080/countrylist")
      .then(res => res.json())
      .then(data => {
        this.setState({ countryDetail: data });
      })
      .catch(console.log);
  }

  buildCtryOptions() {
    var country = [];
    for (let j = 0; j < this.state.countryDetail.length; j++) {
      country.push(
        <option key={j} value={this.state.countryDetail[j].countryCode}>
          {this.state.countryDetail[j].countryName}
        </option>
      );
    }
    country.push(<option key="" defaultValue=""></option>);
    return country;
  }

  buildDepotOptions() {
    var depot = [];
    for (let j = 0; j < this.state.depotDetail.length; j++) {
      depot.push(
        <option key={j} value={this.state.depotDetail[j].depotId}>
          {this.state.depotDetail[j].depotId}
        </option>
      );
    }
    depot.push(<option key="" defaultValue=""></option>);
    return depot;
  }
  handleDepot() {
    fetch("http://localhost:8080/depotlist", {
      method: "post",
      body: JSON.stringify({ countryCode: this.state.countryCode })
    })
      .then(res => res.json())
      .then(data => {
        this.setState({ depotDetail: data });
      })
      .catch(console.log);
  }
  handleCountry = event => {
    alert(event.target.value);
    this.setState({ countryCode: event.target.value });

    // setTimeout(() => { console.log(this.state.countryName);}, 100);
    setTimeout(() => {
      this.handleDepot();
    }, 100);
  };
  handleDepotId = event => {
    alert(event.target.value);
    this.setState({ depotId: event.target.value });
  };

  handleSlotDate = event => {
    this.setState({ slotDate: event.target.value });
  };

  handleSubmit = event => {
    if (this.handleValidation()) {
      alert(this.state.countryCode + this.state.depotId + this.state.slotDate);
      fetch("http://localhost:8080/depotId/countryCode/slotDate/", {
        method: "post",
        body: JSON.stringify({
          depotId: this.state.depotId,
          countryCode: this.state.countryCode,
          slotDate: this.state.slotDate
        })
      })
        .then(res => res.json())
        .then(data => {
          this.setState({ slotDetail: data });
        })
        .catch(console.log);
      this.setState({ hide: true });
    } else {
      alert("Please fill the required field in proper format");
    }
  };
  handleBookSlot = event => {
    fetch("http://localhost:8080/slotupdate", {
      method: "put",
      body: JSON.stringify({ slotId: event.target.value })
    });
    alert("Slot Booked" + event.target.value);
    this.handleSubmit();
    this.renderTableData();
  };
  renderTableData() {
    return this.state.slotDetail.map((slot, index) => {
      console.log("check" + slot + index);
      const { slotId, countryCode, depotId, slotTime } = slot; //destructuring
      return (
        <tr key={slotId}>
          <td>{slotId}</td>
          <td>{countryCode}</td>
          <td>{depotId}</td>
          <td>{slotTime}</td>
          <td>
            <button type="button" value={slotId} onClick={this.handleBookSlot}>
              Book
            </button>
          </td>
        </tr>
      );
    });
  }
  handleValidation = event => {
    let errors = {};
    let formIsValid = true;
    var date_pattern = /^(0?[1-9]|[12][0-9]|3[01])[/](0?[1-9]|1[012])[/]\d{4}$/;
    console.log(date_pattern.test("29/02/2020"));
    if (!this.state.depotId) {
      formIsValid = false;
      errors["depotId"] = "Cannot be empty";
    }
    //country code
    if (!this.state.countryCode) {
      formIsValid = false;
      errors["countryCode"] = "Cannot be empty";
    }
    //slotDate
    if (!this.state.slotDate || !date_pattern.test(this.state.slotDate)) {
      formIsValid = false;
      errors["slotDate"] = "Cannot be empty";
    }
    this.setState({ errors: errors });
    return formIsValid;
  };

  render() {
    return (
      <div className="Slotbooking">
        <form>
          <label>
            Country:
            <select value={this.state.value} onChange={this.handleCountry}>
              {this.buildCtryOptions()}
            </select>
          </label>
          <label>
            Depot:
            <select value={this.state.value} onChange={this.handleDepotId}>
              {this.buildDepotOptions()}
            </select>
          </label>
          <label>
            Date:
            <input
              type="text"
              value={this.state.slotDate}
              onChange={this.handleSlotDate}
            />
          </label>
          <button type="button" onClick={this.handleSubmit}>
            Fetch
          </button>
        </form>
        {this.state.hide ? (
          <div>
            <h1 id="title">Slot Details</h1>
            <table id="slots">
              <tbody>
                <tr>
                  <th>SlotId</th>
                  <th>CountryCode</th>
                  <th>DepotId</th>
                  <th>SlotTime</th>
                </tr>
                {this.renderTableData()}
              </tbody>
            </table>
          </div>
        ) : null}
      </div>
    );
  }
}
export default Slotbooking;
