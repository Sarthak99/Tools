import React from "react";
import "../stylesheets/Display_PO.css";
// import DataTable from 'react-data-table-component';
import SmartDataTable from "react-smart-data-table";

const PATH_BASE = "http://localhost:8080";
const PATH_SEARCH = "/purchase_orders"

class Display_PO extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            isLoading: true,
            poDetails: null,
            columns: {
                "ColumnNames":
                    [   
                        "PO Number", "Supplier Name", "PO Delivery Date", "PO Delivery Not After Date",
                        "Appointment Number", "Appointment Date", "Tesco Ship To Name", "Number of Cases in PO", "Number of Cases in Reciept",
                        "Reciept Number", "Depot Turnaround", "Status"
                    ],

                "FieldNames": 
                    [   "poNumber", null, "deliveryNotBeforeDate", "deliveryNotAfterDate", null, null, "depotID", null, null, null, null, null]
        
                },

            filterValue: '',
            orderedHeaders:[
                "poNbr",
                "supplierName",
                "poDate",
                "deliveryDate",
                "apptNbr",
                "apptEndTs",
                "buyerDetails",
                "totalCases",
                "numberOfCasesInReceipt",
                "receiptNumber",
                "depotTurnaround",
                "status"
            ]

            }

        this.getColumns = this.getColumns.bind(this);
    }

    async componentDidMount(){
        try{
            const URL = `${PATH_BASE}${PATH_SEARCH}`;
            console.log(URL);
            const response = await fetch(URL);
            console.log(response);
            //Check for Error 404.
            if(!response.ok) {
                throw Error(response.statusText);
              }
              const bodyJson = await response.json();
              this.setState({poDetails:bodyJson, isLoading:false});
        }catch (error){
            console.log(error);
        }
    }


    getHeaders(){
        return {
            poNbr:{
                text:"PO Number",
                filterable: true,
                sortable: true,
            },
            supplierName:{
                text:"Supplier Name"
            },
            poDate:{
                text: "PO Delivery Date",
            },
            deliveryDate:{
                text:"PO Delivery Not After Date",
                filterable: false,
                sortable: true
            },
            apptNbr:{
                text: "Appointment Number"
            },
            apptEndTs:{
                text: "Appointment Date"
            },
            buyerDetails:{
                text: "Tesco Ship to Name"
            },
            totalCases:{
                text: "Number of cases in PO"
            },
            numberOfCasesInReceipt:{
                text: "Number of cases in receipt"
            },
            receiptNumber:{
                text: "Receipt Number"
            },
            depotTurnaround:{
                text: "Depot Turnaround"
            },
            status:{
                text: "Status",
                value: "Not Appointed"
            }
        }
    }
    getColumns(){
        var columns = [];
        for(let i = 0; i < this.state.columns.ColumnNames.length; i++){
            // columns[i] = {
            //     name: this.state.columns.ColumnNames[i],
            //     selector: this.state.columns.FieldNames[i],
            //     sortable: true
            // }
        }
        return columns;
    }
    
    render(){
        if(this.state.isLoading){
            return <p>Loading</p>
        }
        return (
            <React.Fragment>
                <input type="text" onChange={this.handleChangeFilter} />
                <div className="Display_PO">
                    <SmartDataTable
                        data={this.state.poDetails}
                        name="Purchase Orders"
                        sortable/>
                    {/* <DataTable 
                        title = "Purchase Orders"
                        columns = {this.getColumns()}
                        data = {this.state.poDetails}
                        /> */}
                </div>
            </React.Fragment>
        )
    }
}

export default Display_PO;