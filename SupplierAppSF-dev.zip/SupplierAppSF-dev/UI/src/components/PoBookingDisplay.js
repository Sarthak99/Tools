import React from "react";
//import Table from "react-bootstrap/Table";
//import Checkbox from "./Checkbox";

class PoBookingDisplay extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      countryDetail: [],
      countryCode: "",
      depotDetail: [],
      deliveryDate: "",
      depotId: "",
      PODetail: [],
      hide: false,
      vendor_NBR: "54750",
      poList: [],
      slotDetail: [],
      slotId: "",
      errors: {
        countryCode: "",
        depotId: "",
        deliveryDate: ""
      }
    };
    this.handleDepot = this.handleDepot.bind(this);
  }

  //This function will automatically render whenever the page is reloaded.
  componentDidMount() {
    document.title = "Supplier Appointments";
    fetch("http://localhost:8080/countrylist")
      .then(res => res.json())
      .then(async data => {
        await this.setState({ countryDetail: data });
      })
      .catch(console.log);
  }

  //This function will fetch the list of depot from couchbase based on countrycode
  handleDepot() {
    fetch("http://localhost:8080/depotlist", {
      method: "post",
      body: JSON.stringify({ countryCode: this.state.countryCode })
    })
      .then(res => res.json())
      .then(async data => {
        await this.setState({ depotDetail: data });
      })
      .catch(console.log);
  }

  //Function to display list of country as a dropdown at the time of page loading itself
  buildCtryOptions() {
    var country = [];
    for (let j = 0; j < this.state.countryDetail.length; j++) {
      country.push(
        <option key={j} value={this.state.countryDetail[j].countryCode}>
          {this.state.countryDetail[j].countryName}
        </option>
      );
    }
    country.push(<option key="" defaultValue=""></option>);
    return country;
  }

  //Function to display list of depot based on selected Country.
  buildDepotOptions() {
    var depot = [];
    for (let j = 0; j < this.state.depotDetail.length; j++) {
      depot.push(
        <option key={j} value={this.state.depotDetail[j].depotId}>
          {this.state.depotDetail[j].depotId}
        </option>
      );
    }
    depot.push(<option key="" defaultValue=""></option>);
    return depot;
  }

  //This function will set the state of countryCode based on user selection of country name.
  handleCountry = async event => {
    alert(event.target.value);
    await this.setState({ countryCode: event.target.value });
    this.handleDepot();
  };

  //This function will set the state of depotId based on user selection of depot.
  handleDepotId = async event => {
    alert(event.target.value);
    await this.setState({ depotId: event.target.value });
  };

  //This function will set the state of deliveryDate based on user input for date.
  handledeliveryDate = async event => {
    await this.setState({ deliveryDate: event.target.value });
  };

  //Function defined for form falidation
  handleValidation = event => {
    let errors = {};
    let formIsValid = true;
    var date_pattern = /^([12]\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))$/;
    //depotId validation
    if (!this.state.depotId) {
      formIsValid = false;
      errors["depotId"] = "Cannot be empty";
    }
    //countrycode validation
    if (!this.state.countryCode) {
      formIsValid = false;
      errors["countryCode"] = "Cannot be empty";
    }
    //deliveryDate validation
    if (
      !this.state.deliveryDate ||
      !date_pattern.test(this.state.deliveryDate)
    ) {
      formIsValid = false;
      errors["deliveryDate"] = "Cannot be empty";
    }
    this.setState({ errors: errors });
    return formIsValid;
  };
  handleSubmit = async event => {
    if (this.handleValidation()) {
      alert(
        this.state.countryCode + this.state.depotId + this.state.deliveryDate
      );
      let urlfetch =
        "http://localhost:8080/purchaseorder/vendorenumber?vendor_NBR=" +
        this.state.vendor_NBR +
        "&deliveryDate=" +
        this.state.deliveryDate +
        "&countryCode=" +
        this.state.countryCode +
        "&depotId=" +
        this.state.depotId;
      fetch(urlfetch)
        .then(res => res.json())
        .then(data => {
          this.setState({ PODetail: data });
        })
        .catch(console.log);

      fetch("http://localhost:8080/depotId/countryCode/slotDate/", {
        method: "post",
        body: JSON.stringify({
          depotId: this.state.depotId,
          countryCode: this.state.countryCode,
          slotDate: this.state.deliveryDate
        })
      })
        .then(res => res.json())
        .then(data => {
          this.setState({ slotDetail: data });
        })
        .catch(console.log);

      setTimeout(() => {
        console.log(this.state.slotDetail);
      }, 100);
      this.setState({ hide: true });
    } else {
      alert("Please fill the required field in proper format");
    }
  };

  //Checkboxes for PO's
  handleCheckbox = async event => {
    var tempArray = [...this.state.poList];
    var index = tempArray.indexOf(event.target.value);

    if (index !== -1) {
      tempArray.splice(index, 1);
    } else {
      tempArray.push(event.target.value);
    }
    await this.setState({ poList: tempArray });
    console.log(this.state.poList);
    alert("selected");
  };

  //Build slot in select
  buildSlotOptions() {
    var slotTime = [];
    for (let j = 0; j < this.state.slotDetail.length; j++) {
      slotTime.push(
        <option key={j} value={this.state.slotDetail[j].slotId}>
          {this.state.slotDetail[j].slotTime}
        </option>
      );
    }
    slotTime.push(<option key="" defaultValue=""></option>);
    return slotTime;
  }

  renderTableData() {
    return this.state.PODetail.map((po, index) => {
      const { po_NBR, depotId } = po; //destructuring
      // var tempArray = [...this.state.poList];
      // tempArray.push(po_NBR);
      // this.setState({ poList: tempArray });
      return (
        <tr key={po_NBR}>
          <td>{po_NBR}</td>
          <td>{depotId}</td>
          <td>
            <input
              type="checkbox"
              value={po_NBR}
              onChange={this.handleCheckbox}
              className="form-check-input"
            />
          </td>
        </tr>
      );
    });
  }

  //Function to set state of slot time
  handleSlotTime = async event => {
    await this.setState({ slotId: event.target.value });
    console.log(this.state.slotId);
  };

  handleFormSubmit = async event => {
    if (this.state.poList.length === 0) alert("Select at least one PO");
    else if (!this.state.slotId) alert("Select a slot");
    else {
      alert(
        "Appointment created for slot" +
          this.state.slotId +
          "for POs" +
          this.state.poList
      );
      await fetch("http://localhost:8080/slotupdate", {
        method: "put",
        body: JSON.stringify({ slotId: this.state.slotId })
      }).catch(console.log);
      window.location.reload();
    }
  };
  render() {
    return (
      <div className="Slotbooking">
        <form>
          <label>
            Country:
            <select value={this.state.value} onChange={this.handleCountry}>
              {this.buildCtryOptions()}
            </select>
          </label>
          <label>
            Depot:
            <select value={this.state.value} onChange={this.handleDepotId}>
              {this.buildDepotOptions()}
            </select>
          </label>
          <label>
            Date:
            <input
              type="text"
              value={this.state.deliveryDate}
              onChange={this.handledeliveryDate}
              placeholder="yyyy-mm-dd"
            />
          </label>
          <button type="button" onClick={this.handleSubmit}>
            Fetch
          </button>
        </form>
        {this.state.hide ? (
          <div>
            <form onSubmit={this.handleFormSubmit}>
              <h1 id="title">Valid PO's</h1>
              <table>
                <thead>
                  <tr>
                    <th>PO_NBR</th>
                    <th>Depot_Id</th>
                  </tr>
                  <br></br>
                </thead>
                <tbody>{this.renderTableData()}</tbody>
              </table>
              <label>
                Available Slots:
                <select value={this.state.value} onChange={this.handleSlotTime}>
                  {this.buildSlotOptions()}
                </select>
              </label>
              <button type="submit" className="btn btn-primary">
                Book Slot
              </button>
            </form>
          </div>
        ) : null}
      </div>
    );
  }
}

export default PoBookingDisplay;
//2020-03-04
