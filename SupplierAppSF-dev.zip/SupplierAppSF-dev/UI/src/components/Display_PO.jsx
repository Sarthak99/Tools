import React from "react";
import "../stylesheets/Display_PO.css";
// import DataTable from 'react-data-table-component';
import SmartDataTable from "react-smart-data-table";
import FormContainer from "./FormContainer";

const PATH_BASE = "http://localhost:8080";
const PATH_SEARCH = "/purchase_orders"

class Display_PO extends React.Component{
    constructor(props){
        super(props);
        this.state = {
            isLoading: true,
            poDetails: null,
            columns: {
                "ColumnNames":
                    [   
                        "PO Number", "Supplier Name", "PO Delivery Date", "PO Delivery Not After Date",
                        "Appointment Number", "Appointment Date", "Tesco Ship To Name", "Number of Cases in PO", "Number of Cases in Reciept",
                        "Reciept Number", "Depot Turnaround", "Status"
                    ],

                "FieldNames": 
                    [   "poNumber", null, "deliveryNotBeforeDate", "deliveryNotAfterDate", null, null, "depotID", null, null, null, null, null]
        
                },
            filterValue: '',
            orderedHeaders:[
                "poNbr",
                "supplierName",
                "poDate",
                "deliveryDate",
                "apptNbr",
                "apptEndTs",
                "buyerDetails",
                "totalCases",
                "numberOfCasesInReceipt",
                "receiptNumber",
                "depotTurnaround",
                "status"
            ],
            queryFields:{
                supplierNo: "",
                supplierName: "",
                tescoShipToId: "",
                tescoShipToName: "",
                poDeliveryDate: "",
                status: "",
                poNbr: ""
            }
            }

        this.getColumns = this.getColumns.bind(this);
        this.getHeaders = this.getHeaders.bind(this);
        this.fetchData = this.fetchData.bind(this);
        this.handleFormChange=this.handleFormChange.bind(this);
        this.handleOnChange = this.handleOnChange.bind(this);
        this.handleFormSubmit = this.handleFormSubmit.bind(this);
    }

    handleOnChange = event => {
        this.setState({filterValue: event.target.value});
    }

    handleFormChange(e){
        let value = e.target.value;
        let key = e.target.name;
        this.setState( prevState => (
            { queryFields: 
                {
                    ...prevState.queryFields,
                    [key]: value
                }
            })
        )
    }

    async fetchData(){
        try{
            const URL = `${PATH_BASE}${PATH_SEARCH}`;

            const response = await fetch(URL, {
            method:"POST",
            body: JSON.stringify(this.state.queryFields),
            header:{
                'Accept': 'application/json',
                'Content-Type': 'application/json'
                },
            });
            //Check for Error 404.
            if(!response.ok) {
                throw Error(response.statusText);
              }
              const bodyJson = await response.json();
              this.setState({poDetails:bodyJson, isLoading:false});
              console.log(bodyJson);
        }catch (error){
            console.log(error);
        }
    }
    componentDidMount(){
        this.fetchData();
    }

    getHeaders(){
        return {
            poNbr:{
                text:"PO Number",
                filterable: true,
                sortable: true,
            },
            supplierName:{
                text:"Supplier Name"
            },
            poDate:{
                text: "PO Delivery Date",
            },
            deliveryDate:{
                text:"PO Delivery Not After Date",
                filterable: false,
                sortable: true
            },
            apptNbr:{
                text: "Appointment Number"
            },
            apptEndTs:{
                text: "Appointment Date"
            },
            buyerDetails:{
                text: "Tesco Ship to Name"
            },
            totalCases:{
                text: "Number of cases in PO"
            },
            numberOfCasesInReceipt:{
                text: "Number of cases in receipt"
            },
            receiptNumber:{
                text: "Receipt Number"
            },
            depotTurnaround:{
                text: "Depot Turnaround"
            },
            status:{
                text: "Status",
                value: "Not Appointed"
            }
        }
    }

    getColumns(){
        var columns = [];
        for(let i = 0; i < this.state.columns.ColumnNames.length; i++){
            columns[this.state.columns.FieldNames[i]] = {
                    text: this.state.columns.ColumnNames[i],
                    filterable: true,
                    sortable:true,
            }
            // columns[i] = {
            //     name: this.state.columns.ColumnNames[i],
            //     selector: this.state.columns.FieldNames[i],
            //     sortable: true
            // }
        }
        return columns;
    }
    
    handleFormSubmit(e){
        e.preventDefault();
        this.fetchData();
    }
    render(){
        if(this.state.isLoading){
            return <p>Loading</p>
        }
        return (
            <React.Fragment>
                <FormContainer 
                    queryData={this.state.queryFields}
                    onChangeHandler={this.handleFormChange}
                    onSubmitHandler={this.handleFormSubmit}/>
                <div>
                    <input type='text'
                    name='filterValue'
                    value={this.state.filterValue}
                    placeholder='Filter results...'
                    onChange={this.handleOnChange} />
                </div>

                <div className="Display_PO">
                    <SmartDataTable
                        data={this.state.poDetails}
                        name="Purchase Orders"
                        headers={this.getHeaders()}
                        filterValue={this.state.filterValue}
                        sortable
                        perPage={10}
                        orderedHeaders={this.state.orderedHeaders}
                        hideUnordered={true}/>
                    {/* <DataTable 
                        title = "Purchase Orders"
                        columns = {this.getColumns()}
                        data = {this.state.poDetails}
                        /> */}
                </div>
            </React.Fragment>
        )
    }
}

export default Display_PO;