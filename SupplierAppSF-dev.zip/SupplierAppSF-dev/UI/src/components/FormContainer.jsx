import React, { Component } from "react";
import Input from "./FormComponents/Input";
import Select from "./FormComponents/Select";
import Button from "./Button";


const PATH_BASE = "http://localhost:8080";
const PATH_SEARCH = "/purchase_orders"

class FormContainer extends Component{
    constructor(props){
        super(props);

        this.state = {
            statusOptions: ["Not Appointed", "Appointed", "Delivered", "Expired"]
        }
    }

    render(){
        return(
            <form className="container" onSubmit={this.props.onSubmitHandler}>
                <Input type={'text'}
                        name={'supplierNo'}
                        title={'Supplier Id'}
                        value={this.props.queryData.supplierNo}
                        placeholder={""}
                        onChangeHandler={this.props.onChangeHandler}/>

                <Input type={'text'}
                        name={'supplierName'}
                        title={'Supplier Name'}
                        value={this.props.queryData.supplierName}
                        placeholder={""}
                        onChangeHandler={this.props.onChangeHandler}/>
                <Input type={'text'}
                        name={'tescoShipToId'}
                        title={'TESCO Ship to Id'}
                        value={this.props.queryData.tescoShipToId}
                        placeholder={""}
                        onChangeHandler={this.props.onChangeHandler}/>
                <Input type={'text'}
                        name={'tescoShipToName'}
                        title={'TESCO Ship to Name'}
                        value={this.props.queryData.tescoShipToName}
                        placeholder={""}
                        onChangeHandler={this.props.onChangeHandler}/>
                <Input type={'text'}
                        name={'poDeliveryDate'}
                        title={'PO Delivery Date'}
                        value={this.props.queryData.poDeliveryDate}
                        placeholder={""}
                        onChangeHandler={this.props.onChangeHandler}/>
                <Input type={'text'}
                        name={'poNbr'}
                        title={'PO Number'}
                        value={this.props.queryData.poNbr}
                        placeholder={""}
                        onChangeHandler={this.props.onChangeHandler}/>
                <Select
                    title={'Status'}
                    name={'status'}
                    options={this.state.statusOptions}
                    value={this.props.queryData.status}
                    placeholder={'Select PO Status'}
                    onChangeHandler={this.props.onChangeHandler}
                    />
                <Button 
                    action = {this.props.onSubmitHandler}
                    type = {'primary'}
                    title = {'Search Purchase Orders'}/>
            </form>
        );
    }
}

export default FormContainer;
