import React from "react";

import { NavLink } from "react-router-dom";

const Navigation = () => {
  return (
    <div>
      <NavLink to="/" style={{ padding: "10px" }}>
        Home
      </NavLink>
      <NavLink to="/slotbooking" style={{ padding: "10px" }}>
        Slotbooking
      </NavLink>
      <NavLink to="/purchase_orders" style={{ padding: "10px" }}>
        View Purchase Orders
      </NavLink>
    </div>
  );
};

export default Navigation;
