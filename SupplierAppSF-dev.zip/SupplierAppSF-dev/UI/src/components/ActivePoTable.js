import React from "react";
import DataTable from "react-data-table-component";

class ActivePoTable extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      PODetail: [],
      columnForActivePo: {
        ColumnNames: ["PO Number", "Delivery Date"],
        FieldNames: ["poNbr", "deliveryDate"]
      }
    };
  }
  async componentDidMount() {
    //this.props.onSelectPO([]);
    const urlfetch =
      "http://localhost:8080/purchaseorder/vendorenumber?vendor_NBR=" +
      this.props.vendor_NBR +
      "&deliveryDate=" +
      this.props.deliveryDate +
      "&countryCode=" +
      this.props.countryCode +
      "&depotId=" +
      this.props.depotId;
    console.log("Api hut" + urlfetch);
    const response = await fetch(urlfetch);
    const data = await response.json();
    await this.setState({ PODetail: data });
    console.log(this.state.PODetail);
  }
  getColumnsForActivePo() {
    var columns = [];
    for (let i = 0; i < this.state.columnForActivePo.ColumnNames.length; i++) {
      columns[i] = {
        name: this.state.columnForActivePo.ColumnNames[i],
        selector: this.state.columnForActivePo.FieldNames[i],
        sortable: true
      };
    }
    return columns;
  }

  //Handle row check box
  updateState = state => {
    console.log(state.selectedRows);
    var temp_data = state.selectedRows;
    var tempArray = [];
    for (let i = 0; i < temp_data.length; ++i) {
      //console.log(JSON.stringify(temp_data[i]));
      tempArray.push(temp_data[i]);
    }
    this.props.onSelectPo(tempArray);
  };

  render() {
    return (
      <DataTable
        columns={this.getColumnsForActivePo()}
        data={this.state.PODetail}
        selectableRows={true}
        keyField={this.state.PODetail.po_NBR}
        highlightOnHover={true}
        selectableRowsHighlight={true}
        onSelectedRowsChange={this.updateState}
        pagination={true}
        paginationRowsPerPageOptions={[10, 30, 50]}
        responsive={true}
        // paginationResetDefaultPage={true}
      />
    );
  }
}
export default ActivePoTable;
