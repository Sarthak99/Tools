import React from "react";
import DataTable from "react-data-table-component";
class PoSummary extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      poSummary: [],
      columnsPoSummary: {
        ColumnNames: [
          "Tesco ship to name",
          "Delivery Date",
          "Pending Orders",
          "Total Cases"
        ],
        FieldNames: [
          "depotIdbuyerDetails",
          "deliveryDate",
          "noOfOrders",
          "cases"
        ]
      }
    };
  }
  async componentDidMount() {
    //this.props.onTest("english");
    console.log(this.props.vendor_NBR);
    const url =
      "http://localhost:8080/getposummary?type=PO&userId=" +
      this.props.vendor_NBR;
    const response = await fetch(url);
    const data = await response.json();
    await this.setState({ poSummary: data });
    //console.log(this.state.poSummary);
  }
  getColumnsForPoSummary() {
    var columns = [];
    for (let i = 0; i < this.state.columnsPoSummary.ColumnNames.length; i++) {
      columns[i] = {
        name: this.state.columnsPoSummary.ColumnNames[i],
        selector: this.state.columnsPoSummary.FieldNames[i],
        sortable: true
      };
    }

    return columns;
  }
  render() {
    return (
      <div>
        <DataTable
          title="PO Summary"
          columns={this.getColumnsForPoSummary()}
          data={this.state.poSummary}
          highlightOnHover={true}
          pagination={true}
          paginationRowsPerPageOptions={[10, 30, 50]}
          responsive={true}
        />
      </div>
    );
  }
}
export default PoSummary;
