import React from "react";

class AppointmentCreation extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      apptRef: ""
    };
  }
  async componentDidMount() {
    console.log("Inside Appointment Creation");
    const url = "http://localhost:8080/apptref";
    const response = await fetch(url);
    const data = await response.json();
    await this.setState({ apptRef: data });
  }
}
export default AppointmentCreation;
