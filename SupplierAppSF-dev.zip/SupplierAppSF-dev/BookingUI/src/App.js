import React from 'react';
import logo from './logo.svg';
import './App.css';

const PATH_BASE = "http://localhost:8080";
const PATH_SEARCH = "/depotId/countryCode/slotDate";
const PARAM_SEARCH_1 = "depotId=";
const PARAM_SEARCH_2 = "countryCode="
const QUERY_DEFAULT_DEPOT = "902";
const QUERY_DEFAULT_COUNTRY = "TH"

class App extends React.Component{
  constructor() {
    super();
    this.state = { 
      isLoading: true,
      result: null,
    };
    this.fetchSlots = this.fetchSlots.bind(this);
    this.handleOnClick = this.handleOnClick.bind(this);
    this.handleInputChange = this.handleInputChange.bind(this);
  }

  async fetchSlots(depotID, countryCode, slotDate){
    const requestOptions = {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        depotId: depotID , 
        countryCode: countryCode, 
        slotDate: slotDate         
        })
    };
    try{
        const url = `${PATH_BASE}${PATH_SEARCH}`;
        console.log(url);
        const response = await fetch ("http://localhost:8080/depotId/countryCode/slotDate/", requestOptions);
        //Check for Error 404.
        if(!response.ok) {
          throw Error(response.statusText);
        }
        const bodyJson = await response.json();
        this.setState({result:bodyJson, isLoading:false});
    }catch (error) {
        console.log(error)
    }
  }

  handleInputChange(event){
    this.setState(
      {
        [event.target.name]: event.target.value
      }
    );
    console.log(event.target.name);
  }
  handleOnClick(event){
    event.preventDefault();
    const {searchTerm1, searchTerm2} = this.state;
    console.log(searchTerm1 + searchTerm2);
    this.fetchSlots(searchTerm1, searchTerm2);
  }

  componentDidMount(){
    const {searchTerm1, searchTerm2} = this.state;
    this.fetchSlots("902","TH", "29/02/2020");
  }

  render() {
    const {result, isLoading} = this.state;

    if(isLoading) {
      return <p>Loading...</p>;
    }
    return (
      <div className="App">
        <header className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <div className = "depot_select_form">
            <form onSubmit={this.onClick}>
              <label htmlFor="countryCode"> 
                Select Country:
                <select 
                  name= "searchTerm2"
                  value={this.state.countryCode}
                  onChange={this.handleInputChange}>
                <option value="TH"> Thailand </option>
                <option value="ML"> Malaysia </option>
                </select>
              </label> 
              <br/>
              <label htmlFor="depotID"> 
                Select DepotID:
                <select
                  name = "searchTerm1" 
                  value={this.state.depotID} 
                  onChange={this.handleInputChange}>
                  <option value="902"> DC902</option>
                  <option value="901"> DC901</option>
                </select>
              </label>
              <br/>
              <button type="submit" className="SearchSlots" onClick={this.handleOnClick}> Search Slots
              </button> 
            </form> 
          </div>
          <div className = "App-welcome-message">
              <h2> Available Slots Information: </h2>
              { 
                this.state.result.map(item => 
                // By assigning a key attribute to each list element, React can identify modified items when the list changes
                  <div key={item.slotId}>
                    Depot: {item.depotId}
                    Country:  {item.countryCode}
                    Slot Date: {item.slotDate}
                    Slots available: {item.noOfSlots}
                  </div>
                )
              }
          </div>
        </header>
      </div>
    );
  }
}

export default App;
