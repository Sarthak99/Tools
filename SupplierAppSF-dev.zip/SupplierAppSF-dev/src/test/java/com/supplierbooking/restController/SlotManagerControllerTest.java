//package com.supplierbooking.restController;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//import java.util.ArrayList;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.supplierbooking.SupplierAppSfApplication;
//import com.supplierbooking.entities.SlotEntity;
//
//@SpringBootTest(classes = SupplierAppSfApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//class SlotManagerControllerTest {
//	
//	@Autowired
//	private SlotManagerController slotManagerController;
//	
//	ArrayList<SlotEntity> list1=new ArrayList<>(); 
//	SlotEntity slot1=new SlotEntity("S_03","902","TH",8,"29/02/2020","08:00","Slot");
//	
//	String input1="{\n" + 
//			"	\"depotId\":\"902\",\n" + 
//			"	\"countryCode\":\"TH\",\n" + 
//			"	\"slotDate\":\"29/02/2020\"\n" + 
//			"}";
//	String input2="{\n" + 
//			"	\"slotId\":\"S_11\"\n" + 
//			"}";
//	@BeforeEach
//	public void before() {
//		list1.add(slot1);
//	}
//	@Test
//	void testGetSlotByDepotCountryAndDate() {
//		assertEquals(list1, slotManagerController.getSlotByDepotCountryAndDate(input1).getBody());
//	}
//	@Test
//	void testGetSlotByDepotCountryAndDateCode() {
//		assertEquals(202,slotManagerController.getSlotByDepotCountryAndDate(input1).getStatusCodeValue());
//		
//	}
//	@Test
//	void testSlotUpdateError() {
//		assertEquals("Error",slotManagerController.slotUpdate(input2).getBody());
//	}
//	
//	@Test
//	void testSlotUpdateErrorCode() {
//		assertEquals(500,slotManagerController.slotUpdate(input2).getStatusCodeValue());
//		
//	}
//
//}
