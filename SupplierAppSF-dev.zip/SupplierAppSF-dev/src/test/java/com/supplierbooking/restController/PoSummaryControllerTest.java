package com.supplierbooking.restController;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.supplierbooking.SupplierAppSfApplication;
import com.supplierbooking.entities.PoSummaryMappingEntity;


@SpringBootTest(classes = SupplierAppSfApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class PoSummaryControllerTest {

	@Autowired
	private PoSummaryController poSummaryController;
	
	ArrayList<PoSummaryMappingEntity> list1=new ArrayList<>();
	
	PoSummaryMappingEntity psme1=new PoSummaryMappingEntity("2020-03-25",null, 2,"SAM KHOK DC1",6);
	PoSummaryMappingEntity psme2=new PoSummaryMappingEntity("2020-03-26",null, 1,"SAM KHOK DC1",6);
	
	@BeforeEach
	private void beforeTest() {
		list1.add(psme1);
		list1.add(psme2);
	}
	
	@Test
	void testGetPoSummaryByUserId() {
		assertEquals(list1,poSummaryController.getPoSummaryByUserId("PO","54751"));
	}

}
