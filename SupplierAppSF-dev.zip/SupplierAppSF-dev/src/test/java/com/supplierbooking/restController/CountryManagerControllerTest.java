//package com.supplierbooking.restController;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//import java.util.ArrayList;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.supplierbooking.SupplierAppSfApplication;
//import com.supplierbooking.entities.CountryEntity;
//
//@SpringBootTest(classes = SupplierAppSfApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//class CountryManagerControllerTest {
//	
//	@Autowired
//	private CountryManagerController countryManagerController;
//	
//	ArrayList<CountryEntity> list1=new ArrayList<>(); 
//	CountryEntity c1=new CountryEntity("TH", "Thailand","Country");
//	CountryEntity c2=new CountryEntity("ML", "Malaysia","Country");
//	
//	@BeforeEach
//	public void before() {
//		list1.add(c2);	
//		list1.add(c1);
//		
//	}
//	
//	@Test
//	void testFindCountry() {
//		assertEquals(list1, countryManagerController.findCountry().getBody());
//	}
//
//}
