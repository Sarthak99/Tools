//package com.supplierbooking.restController;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//import java.util.ArrayList;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.supplierbooking.SupplierAppSfApplication;
//import com.supplierbooking.entities.DepotEntity;
//
//@SpringBootTest(classes = SupplierAppSfApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//class DepotManagerControllerTest {
//	
//	@Autowired
//	private DepotManagerController depotManagerController;
//	
//	private ArrayList<DepotEntity> list1=new ArrayList<>(); 
//	private DepotEntity d1=new DepotEntity("TH901", "TH","901", "Thfrsh","Depot");
//	
//	private String countryCode="{\n" + 
//			"	\"countryCode\":\"TH\"\n" + 
//			"}";
//	
//	@BeforeEach
//	public void before() {
//		list1.add(d1);
//	}
//
//	@Test
//	void testListOfDepot() {
//		assertEquals(list1, depotManagerController.listOfDepot(countryCode).getBody());
//	}
//
//}
