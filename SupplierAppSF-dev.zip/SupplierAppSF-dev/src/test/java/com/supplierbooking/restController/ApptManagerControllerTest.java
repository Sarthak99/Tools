package com.supplierbooking.restController;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.supplierbooking.SupplierAppSfApplication;


@SpringBootTest(classes = SupplierAppSfApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class ApptManagerControllerTest {

	@Autowired
	private ApptManagerController apptManagerController;
	
	
	@Test
	void testFindApptref() {
		assertEquals("12350",apptManagerController.findApptref());
	}

}
