//package com.supplierbooking.services;
//
////import static org.junit.Assert.assertEquals;
//import static org.junit.jupiter.api.Assertions.assertEquals;
//import java.util.ArrayList;
//
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//
//import com.supplierbooking.SupplierAppSfApplication;
//import com.supplierbooking.entities.SlotEntity;
//
//
//@SpringBootTest(classes = SupplierAppSfApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
//public class SlotServiceImplTest {
//	
//	@Autowired
//	SlotServiceImpl slotServiceImpl;
//	
//	
//
//	ArrayList<SlotEntity> list1=new ArrayList<>(); 
//	SlotEntity slot1=new SlotEntity("S_03","902","TH",8,"29/02/2020","08:00","Slot");
//	
//	@BeforeEach
//	public void before() {
//		list1.add(slot1);
//	}
//	
//	
//	@Test
//	public void testfindSlotByDepotIdCountryCodeSlotDate() {
//		assertEquals(list1,slotServiceImpl.findSlotByDepotIdCountryCodeSlotDate("902","TH","29/02/2020"));
//	}
//	
//	
//	
//	
//	
//	
////	private SlotServiceImpl slotServiceImpl;
////	private SlotRepository slotRepository;
////	
////	@Before
////	public void setUp() {
////		slotServiceImpl= new SlotServiceImpl();
////		
////		slotRepository=mock(SlotRepository.class);
////		
////		slotServiceImpl.setSlotRepository(slotRepository);
////	}
////	
////	@Test
////	void testCountSlot() {
////		when(slotRepository.count()).thenReturn((long) 2);
////		
////		
////		
////		assertEquals(2,slotServiceImpl.countSlot("Slot"));
////	}
//
//}
