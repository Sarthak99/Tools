//package com.supplierbooking.services;
//
//import static org.junit.jupiter.api.Assertions.*;
//
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.util.ArrayList;
//import java.util.Date;
//import java.util.List;
//import java.util.concurrent.TimeUnit;
//
//import org.junit.jupiter.api.Test;
//import org.junit.runner.RunWith;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//
//@SpringBootTest
//@RunWith(SpringRunner.class)
//class SlotManagerTest {
//
//	@Autowired
//	private SlotManager slotManager;
//
//	private List<Slot> result;
//
//	@Test
//	void testGetSlot() {
//		String slotDate;
//		Date slotDate1 = null;
//		Date slotDate2;
//		slotDate = "25/02/2020";
//		try {
//			slotDate1 = new SimpleDateFormat("dd/MM/yyyy").parse(slotDate);
//		} catch (ParseException e) {
//			e.printStackTrace();
//
//		}
//
//		List<Slot> expResult = new ArrayList<>();
//		Slot slot1 = new Slot(slotDate1, 10, 10);
//		expResult.add(slot1);
//
//		slotDate2 = new Date(slotDate1.getTime() + TimeUnit.HOURS.toMillis(1));
//		Slot slot2 = new Slot(slotDate2, 1, 10);
//		expResult.add(slot2);
//		result = slotManager.getSlot(slotDate1, 10);
//		assertEquals(expResult, result);
//
//	}
//
//}
