package com.supplierbooking.services;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.ArrayList;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.supplierbooking.SupplierAppSfApplication;
import com.supplierbooking.entities.PoSummaryMappingEntity;


@SpringBootTest(classes = SupplierAppSfApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class PoSummaryServiceImplTest {

	@Autowired
	private PoSummaryServiceImpl poSummaryServiceImpl ;
	
	ArrayList<PoSummaryMappingEntity> list1=new ArrayList<>();
	
	PoSummaryMappingEntity psme1=new PoSummaryMappingEntity("2020-04-01",null, 2,"SAM KHOK DC",12);
	PoSummaryMappingEntity psme2=new PoSummaryMappingEntity("2020-04-02",null, 1,"SAM KHOK DC",6);
	PoSummaryMappingEntity psme3=new PoSummaryMappingEntity("2020-04-02",null, 2,"CENTRAL EXPRESS DC",11);
	
	
	@BeforeEach
	private void beforeTest() {
		list1.add(psme1);
		list1.add(psme3);
		list1.add(psme2);
	}
	
	
	@Test
	void testGetPoSummaryByUserId() {
		assertEquals(list1,poSummaryServiceImpl.getPoSummaryByUserId("PO","54751"));
	}

}
