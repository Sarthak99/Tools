//package com.supplierbooking;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class SupplierAppSfApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
