package com.supplierbooking.configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.Cluster;
import com.couchbase.client.java.CouchbaseCluster;

@Configuration
@Component
public class Config {

	@Value("${spring.couchbase.bootstrap-hosts}")
    private String hostname;

    @Value("${spring.couchbase.bucket.name}")
    private String bucket;

    @Value("${spring.couchbase.bucket.password}")
    private String password;

    public @Bean
    Cluster cluster() {
        return CouchbaseCluster.create(hostname);
    }

    public @Bean
    Bucket bucket() {
        return cluster().openBucket(bucket, password);
    }
}
