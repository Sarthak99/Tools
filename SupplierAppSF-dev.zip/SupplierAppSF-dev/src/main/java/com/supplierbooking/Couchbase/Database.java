//package com.supplierbooking.Couchbase;
//
//import com.couchbase.client.java.Bucket;
//import com.couchbase.client.java.Cluster;
//import com.couchbase.client.java.CouchbaseCluster;
//import com.couchbase.client.java.document.JsonDocument;
//import com.couchbase.client.java.document.json.JsonArray;
//import com.couchbase.client.java.document.json.JsonObject;
//import com.couchbase.client.java.query.*;
//import com.couchbase.client.java.query.consistency.ScanConsistency;
//import org.springframework.dao.DataRetrievalFailureException;
//
//import java.util.ArrayList;
//import java.util.List;
//import java.util.Map;
//
//public class Database {
//    // Initialize the Connection
//    public static void callCouchbaseDatabase() {
//        Cluster cluster = CouchbaseCluster.create("localhost");
//        cluster.authenticate("Order_data", "253854");
//        Bucket bucket = cluster.openBucket("SupplierDataSF_DEV");
//
//        // Create a JSON Document
//        JsonObject arthur = JsonObject.create()
//                .put("name", "Arthur")
//                .put("email", "kingarthur@couchbase.com")
//                .put("interests", JsonArray.from("Holy Grail", "African Swallows"));
//
//        // Store the Document
//        bucket.upsert(JsonDocument.create("u:king_arthur", arthur));
//
//        // Load the Document and print it
//        // Prints Content and Metadata of the stored Document
//        System.out.println(bucket.get("u:king_arthur"));
//
//        // Create a N1QL Primary Index (but ignore if it exists)
//        bucket.bucketManager().createN1qlPrimaryIndex(true, false);
//
//        // Perform a N1QL Query
//        N1qlQueryResult result = bucket.query(
//                N1qlQuery.parameterized("SELECT name FROM `bucketname` WHERE $1 IN interests",
//                        JsonArray.from("African Swallows"))
//        );
//
//        // Print each found Row
//        for (N1qlQueryRow row : result) {
//            // Prints {"name":"Arthur"}
//            System.out.println(row);
//        }
//    }
//}
////    private static final String hostname = "127.0.0.1";
////    private static final String bucketName = "Order_data";
////    private static final String password = "253854";
////
////    private static Cluster cluster;
////    private static Bucket bucket;
////
////    public Database() {
////        this.cluster = CouchbaseCluster.create(hostname);
////        this.bucket = cluster.openBucket(bucketName, password);
////    }
////
////    //function to return all documents in the particular bucket
////    public static List<Map<String, Object>> getPurchaseOrders(){
////        String queryStr = "SELECT META(Order_data).id, poNbr, supplierNo, " +
////                "poDate, deliveryDate, buyerDetails, totalCases " +
////                "FROM `"  + bucket.name() + "` AS poDetails";
////        N1qlQueryResult queryResult = bucket.query(N1qlQuery.simple(queryStr, N1qlParams.build().consistency(ScanConsistency.REQUEST_PLUS)));
////        return extractResultOrThrow(queryResult);
////    }
////
////    public static List<Map<String, Object>> getByDocumentId(final Bucket bucket, String documentId){
////        String queryStr = "SELECT " +
////                "poNbr, supplierNo, poDate, deliveryDate, buyerDetails, totalCases" +
////                "FROM `" + bucket.name() + "` AS poDetails " +
////                "WHERE META(users).id = $1";
////        ParameterizedN1qlQuery query = ParameterizedN1qlQuery.parameterized(queryStr, JsonArray.create().add(documentId));
////        N1qlQueryResult queryResult = bucket.query(query);
////        return extractResultOrThrow(queryResult);
////    }
////
//////    Function to retrieve query results.
//////    This function takes a result from a Couchbase N1QL query,
//////    and loops over the result set while parsing it into a List of Map objects.
////    private static List<Map<String, Object>> extractResultOrThrow(N1qlQueryResult result) {
////        if(!result.finalSuccess()){
////            throw new DataRetrievalFailureException("Query error:" + result.errors());
////        }
////
////        List<Map<String, Object>> content = new ArrayList<Map<String, Object>>();
////        for(N1qlQueryRow row : result){
////            content.add(row.value().toMap());
////        }
////
////        return content;
////    }
////}
