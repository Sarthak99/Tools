package com.supplierbooking;

//import com.supplierbooking.Couchbase.Database;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SupplierAppSfApplication {

	private static final Logger LOGGER = LogManager.getLogger(SupplierAppSfApplication.class);
	
	public static void main(String[] args) {
		
		SpringApplication.run(SupplierAppSfApplication.class, args);
	//	Database.callCouchbaseDatabase();

//		ApptServiceImpl appointment1=(Apgit adptServiceImpl) ctx.getBean(ApptServiceImpl.class);
//		POServiceImpl appointment1=(POServiceImpl) ctx.getBean(POServiceImpl.class);

//		appointment1.findCount();

//		ApptServiceImpl appointment1=(ApptServiceImpl) ctx.getBean(ApptServiceImpl.class);
//
//		ApptDetailEntity l1=new ApptDetailEntity("1", "223344", "02345233", "5", "10", "50");
//		ApptDetailEntity l2=new ApptDetailEntity("3", "223344", "02246275", "11", "1", "11");
//
//		List<ApptDetailEntity>list1 = new ArrayList<ApptDetailEntity>();
//
//		list1.add(l1);
//		list1.add(l2);
//
//
//		ApptEntity a1=new ApptEntity("APPT905TH12345", "", "12345","2020-03-19", "2020-03-20 00:00:01", "2020-03-20 23:59:59", "Created", "Vendor1", "TH", "905", "Appointment", list1);
//
//		appointment1.save(a1);

		//SpringApplication.run(SupplierAppSfApplication.class, args);
		//appointment1.findCount();
		LOGGER.info("Info level log message");
		LOGGER.debug("Debug level log message");
		LOGGER.error("Error level log message");
		
	}

}
