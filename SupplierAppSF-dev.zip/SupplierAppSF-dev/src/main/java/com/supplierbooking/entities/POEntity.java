package com.supplierbooking.entities;

import com.couchbase.client.java.repository.annotation.Field;
import com.couchbase.client.java.repository.annotation.Id;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.data.couchbase.core.mapping.Document;

import javax.validation.constraints.NotNull;
import java.util.List;


@Document
@Data
@AllArgsConstructor
public class POEntity {
    @NotNull
    @Id
    private String id;

    @Field
    private String action;


    @Field
    private String poNbr;

    @Field
    private String asn;

    @Field
    private String poType;

    @Field
    private String supplierName;

    @Field
    private String creditTerms;

    @Field
    private String paymentMethod;

    @Field
    private String SupplierName;

    @Field
    private String supplierAdd1;

    @Field
    private String supplierAdd2;

    @Field
    private String supplierAdd3;

    @Field
    private String supplierContactPerson;

    @Field
    private String supplierContactFax1;

    @Field
    private String supplierContactFax2;

    @Field
    private String supplierContactPhone1;

    @Field
    private String supplierContactPhone2 ;
    
    @Field
    private String supplierNo;

    @Field
    private String poDate;

    @Field
    private String deliveryDate;

    @Field
    private String deliveryTime;

    @Field
    private String cancellationDate;

    @Field
    private String siteDetails;

    @Field
    private String buyerDetails;

	@Field
	private String country;


    @Field
    private String tescoPhoneNo;

    @Field
    private String comments1;

    @Field
    private String comments2;

    @Field
    private String comments3;


    @Field
    private String comments4;

    @Field
    private String comments5;

    @Field
    private String comments6;

    @Field
    private String freeText1;

    @Field
    private String freeText2;

    @Field
    private String freeText3;

    @Field
    private String freeText4;

    @Field
    private String freeText5;

    @Field
    private String freeText6;

    @Field
    private String freeText7;

    @Field
    private String freeText8;

    @Field
    private String totalCases;

    @Field
    private String totalFreeCases;

    @Field
    private String totalUnits;

    @Field
    private String totalPrice;

    @Field
    private String cashDiscountDetails;

    @Field
    private String totalPrice1;

    @Field
    private String alwLabel;

    @Field
    private String alwTotal;

    @Field
    private String totalPrice2;

    @Field
    private String creditTermDays;

    @Field
    private String vat;

    @Field
    private String mallName;

    @Field
    private String taxId;

    @Field
    private String type;

    @Field
    private List<PODetail> detail;

    @Field
    private String apptNbr;

    @Field
    private String apptEndTs;
    @Field
    private String status;
}
