package com.supplierbooking.entities;

import org.springframework.data.couchbase.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;

@Document
@Data
@AllArgsConstructor
public class PoSummaryMappingEntity {
	
	private String deliveryDate;
	private String depotId;
	private int noOfOrders;
	private String buyerDetails;
	private int cases;

}
