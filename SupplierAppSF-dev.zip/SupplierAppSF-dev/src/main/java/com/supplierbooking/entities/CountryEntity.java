//Class to define the data model for Country entity which we stored in couch base db.

package com.supplierbooking.entities;

import javax.validation.constraints.NotNull;

import org.springframework.data.couchbase.core.mapping.Document;

import com.couchbase.client.java.repository.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Data;

@Document
@Data
@AllArgsConstructor
public class CountryEntity {
	
	@NotNull
	@Id
	private String Id;
	
	@NotNull
	private String countryCode;
	
	@NotNull
	private String countryName;
	
	@NotNull
	private String type;
	
}
