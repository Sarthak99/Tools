package com.supplierbooking.entities;

import java.util.List;

import javax.validation.constraints.NotNull;

import org.springframework.data.couchbase.core.mapping.Document;

import com.couchbase.client.java.repository.annotation.Field;
import com.couchbase.client.java.repository.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Data;

@Document
@Data
@AllArgsConstructor
public class ApptEntity {
	
	@NotNull
    @Id
    private String id;
	
	@Field
	private String apptNbr;
	
	@Field
	private String apptRef;
	
	@Field
	private String creationTs;
	
	@Field
	private String apptStartTs;
	
	@Field
	private String apptEndTs;
	
	@Field
	private String apptStatus;
	
	@Field
	private String userId;
	
	@Field
	private String countryCode;
	
	@Field
	private String depotId;
	
	@Field
	private String type;
	
	@Field
	private List<ApptDetailEntity> apptDetailEntity;
	
	
	
	/*
	 *  "type": "Appointment",
  "apptNbr": "",
  "apptRef": "12345",
  "creationTs": "2020-03-19",
  "apptStartTs": "2020-03-20 00:00:01",
  "apptEndTs": "2020-03-20 23:59:59",
  "apptStatus": "Created",
  "userId": "Vendor1",
  "countryCode": "TH",
  "depotId": "905",
	 */

}
