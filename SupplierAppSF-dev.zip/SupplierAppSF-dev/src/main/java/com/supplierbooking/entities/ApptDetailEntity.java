package com.supplierbooking.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class ApptDetailEntity {

	private String apptLine;
	private String poNbr;
	private String itemId;
	private String casepack;
	private String apptdContainerQty;
	private String apptdUnitQty;
}
