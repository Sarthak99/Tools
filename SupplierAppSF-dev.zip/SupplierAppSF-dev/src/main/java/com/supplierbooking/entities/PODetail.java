package com.supplierbooking.entities;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class PODetail {
    private String alwAmtCase;
    private String alwCode;
    private String colorCode;
    private String colorDescription;
    private String department;
    private String discountPerCase;			
    private String finalPricePerCase;
    private String freeCases;
    private String orderedQtyCases;
    private String orderedQtyUnits;
    private String orgOrderedQtyCases;
    private String packSize;
    private String packSize2;
    private String prepackType;
    private String pricePerCase;
    private String prodPrepackValue;
    private String productDescTpnd;
    private String ramsFreshTerm;
    private String sizeDesc;
    private String sizeType;
    private String sku;
    private String styleNo;
    private String traySize;
    private String unitOfMeasure;
    private String upc;
    private String vat;
    private String vpn;

}


