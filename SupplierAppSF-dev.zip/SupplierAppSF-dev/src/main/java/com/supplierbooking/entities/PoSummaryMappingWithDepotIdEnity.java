package com.supplierbooking.entities;

import org.springframework.data.couchbase.core.mapping.Document;

import lombok.AllArgsConstructor;
import lombok.Data;

@Document
@Data
@AllArgsConstructor
public class PoSummaryMappingWithDepotIdEnity {
	
	private String deliveryDate;
	private String depotIdbuyerDetails;
	private int noOfOrders;
	private int cases;

}
