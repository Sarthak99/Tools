//Class to define the data model for slotentity which we stored in couchbase db.

package com.supplierbooking.entities;

import org.springframework.data.couchbase.core.mapping.Document;

import com.couchbase.client.java.repository.annotation.Field;
import com.couchbase.client.java.repository.annotation.Id;



import javax.validation.constraints.NotNull;
import lombok.*;

@Document
@Data
@AllArgsConstructor
public class SlotEntity{

	@NotNull
	@Id
	private String slotId;
	
	@NotNull
	@Field
	private String depotId;
	
	@NotNull
	@Field
	private String countryCode;
	
	@NotNull
	@Field
	private int noOfSlots;
	
	@Field
	@NotNull
	private String slotDate;
	
	@Field
	@NotNull
	private String slotTime;
	
	@NotNull
	@Field
	private String type;
	
	
}
