//Class to define the data model for Depot Entity which we stored in couch base db.

package com.supplierbooking.entities;

import javax.validation.constraints.NotNull;

import org.springframework.data.couchbase.core.mapping.Document;

import com.couchbase.client.java.repository.annotation.Field;
import com.couchbase.client.java.repository.annotation.Id;

import lombok.AllArgsConstructor;
import lombok.Data;

@Document
@Data
@AllArgsConstructor
public class DepotEntity {
	
	@NotNull
	@Id
	private String id;
	
	@NotNull
	@Field
	private String countryDepot;
	
	@NotNull
	@Field
	private String countryCode;
	
	@NotNull
	@Field
	private String depotId;
	
	@NotNull
	@Field
	private String depotName;
	
	@NotNull
	@Field
	private String type;
	

}
