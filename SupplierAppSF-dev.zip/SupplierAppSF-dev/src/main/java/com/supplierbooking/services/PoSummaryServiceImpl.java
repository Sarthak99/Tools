package com.supplierbooking.services;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataRetrievalFailureException;
import org.springframework.stereotype.Service;

import com.couchbase.client.java.Bucket;
import com.couchbase.client.java.document.json.JsonArray;
import com.couchbase.client.java.query.N1qlQuery;
import com.couchbase.client.java.query.N1qlQueryResult;
import com.couchbase.client.java.query.N1qlQueryRow;
import com.couchbase.client.java.query.ParameterizedN1qlQuery;
import com.google.gson.Gson;
import com.supplierbooking.configuration.Config;
import com.supplierbooking.entities.ApptEntity;
import com.supplierbooking.entities.PoSummaryMappingEntity;
import com.supplierbooking.entities.PoSummaryMappingWithDepotIdEnity;

@Service
public class PoSummaryServiceImpl {

	// log4j used for logging the logs for an application.
	static final Logger log4j = LogManager.getLogger(PoSummaryServiceImpl.class);

	@Autowired
	private Config config;

	public List<PoSummaryMappingWithDepotIdEnity> getPoSummaryByUserId(String type, String userId) {

		try {
			List<String>validDates=dateCalculationForPoSummary();
			String poSummaryQuery = "SELECT Substr(siteDetails,1) as depotId,buyerDetails,deliveryDate,count(*) as noOfOrders,sum(TONUMBER(totalCases)) as cases " + "FROM `"
					+ config.bucket().name() + "`"
					+ "WHERE type = $1  and (poNbr NOT IN $2) and (deliveryDate IN $4) and supplierNo= $3 group by siteDetails,buyerDetails,deliveryDate order by deliveryDate";
			List<String> AppointedPo = getAppointedPO(config.bucket(), "Appointment", "54751");
			System.out.println("list of appointmnet" + AppointedPo);
			System.out.println("List of valid dates"+validDates);
			ParameterizedN1qlQuery distinctBuyerDetailQuery = N1qlQuery.parameterized(poSummaryQuery,
					JsonArray.create().add(type).add(AppointedPo).add(userId).add(validDates));
			N1qlQueryResult distinctBuyerDetailQueryResult = config.bucket().query(distinctBuyerDetailQuery);
			log4j.info("Method succesfull for getting Summary of unappointed PO for a vendor");
			return extractResultOrThrow(distinctBuyerDetailQueryResult);
		} catch (Exception e) {
			log4j.error("Error for getting Summary of unappointed PO for a vendor");
			return null;
		}

	}
	public void getActivePoByUserIdDepotId(String userId,String countryCode,String depotId,String deliveryDate) {
		//List<String>validDates=dateCalculationForActivePo(deliveryDate);
		String activePoQuery="SELECT meta().id " + "FROM `" + config.bucket().name() + "`" + "WHERE type = $1";
		ParameterizedN1qlQuery activePoQueryRun=N1qlQuery.parameterized(activePoQuery, JsonArray.create().add("PO"));
		System.out.println(activePoQueryRun+activePoQuery);
		N1qlQueryResult activePoQueryRunResult=config.bucket().query(activePoQueryRun);
		System.out.println("No of row"+activePoQueryRunResult.allRows().size());
		for (N1qlQueryRow row : activePoQueryRunResult) {
			System.out.println(row.toString());
			//content.add(c1);
		}
		//System.out.println(validDates);
		return;
	}
	

	private List<String> dateCalculationForPoSummary() {
		List<String>validDates=new ArrayList<String>();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		Date date = new Date();
		String deliveryDate=formatter.format(date);
		Calendar c = Calendar.getInstance();
		try {
			c.setTime(formatter.parse(deliveryDate));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		c.add(Calendar.DAY_OF_MONTH,1);
		String deliveryDatePlusOne=formatter.format(c.getTime());
		System.out.println(deliveryDatePlusOne);
		validDates.add(deliveryDate);
		validDates.add(deliveryDatePlusOne);
		return validDates;
	}
	
//	private List<String> dateCalculationForActivePo(String deliveryDate) {
//		List<String>validDates=new ArrayList<String>();
//		String deliveryDatePlusOne;
//		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//		Calendar c = Calendar.getInstance();
//		try {
//			c.setTime(sdf.parse(deliveryDate));
//		} catch (ParseException e) {
//			e.printStackTrace();
//		}
//		// Incrementing the date by 1 day
//		c.add(Calendar.DAY_OF_MONTH, 1);
//		deliveryDatePlusOne = sdf.format(c.getTime());
//		validDates.add(deliveryDate);
//		validDates.add(deliveryDatePlusOne);
//		
//		return validDates;
//
//	}

	private List<String> getAppointedPO(final Bucket bucket, String type, String userId) {
		try {
			String queryStr = "SELECT * " + "FROM `" + bucket.name() + "`" + "WHERE type = $1 and userId = $2 ";
			ParameterizedN1qlQuery query = N1qlQuery.parameterized(queryStr, JsonArray.create().add(type).add(userId));
			N1qlQueryResult queryResult = bucket.query(query);
			List<String> content = new ArrayList<String>();
			Gson gson = new Gson();
			for (N1qlQueryRow row : queryResult) {

				ApptEntity c1 = gson.fromJson(row.value().get("Order_data").toString(), ApptEntity.class);
				for (int i = 0; i < c1.getApptDetailEntity().size(); i++) {
					content.add(c1.getApptDetailEntity().get(i).getPoNbr());
				}

			}
			LinkedHashSet<String> hashSet = new LinkedHashSet<>(content);
			ArrayList<String> listWithoutDuplicates = new ArrayList<>(hashSet);
			log4j.info("Method succesfull for getting list of appointed PO number for a vendor");
			return listWithoutDuplicates;
		} catch (Exception e) {
			log4j.error("Error for getting list of appointed PO number for a vendor ");
			return null;
		}
	}

	private List<PoSummaryMappingWithDepotIdEnity> extractResultOrThrow(N1qlQueryResult result) {
		if (!result.finalSuccess()) {
			throw new DataRetrievalFailureException("Query error: " + result.errors());
		}
		List<PoSummaryMappingWithDepotIdEnity> content = new ArrayList<PoSummaryMappingWithDepotIdEnity>();
		PoSummaryMappingWithDepotIdEnity p1;
		Gson gson = new Gson();
		for (N1qlQueryRow row : result) {
			PoSummaryMappingEntity c1 = gson.fromJson(row.value().toString(), PoSummaryMappingEntity.class);
			//System.out.println(c1.getDepotId()+"::"+c1.getBuyerDetails());
			p1=new PoSummaryMappingWithDepotIdEnity(c1.getDeliveryDate(), c1.getDepotId()+"::"+c1.getBuyerDetails(), c1.getNoOfOrders(), c1.getCases());
			content.add(p1);
		}
		return content;
	}
}
