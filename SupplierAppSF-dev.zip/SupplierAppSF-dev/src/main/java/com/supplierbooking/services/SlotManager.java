//package com.supplierbooking.services;
//
//import java.util.Date;
//import java.util.List;
//
//import org.springframework.stereotype.Service;
//
//@Service
//public class SlotManager {
//
//	private List<Slot> slots;
//	private static DepotSlots depotSlots;
//
//	public List<Slot> getSlot(Date requiredDate, int dcId) {
//		depotSlots = new DepotSlots(dcId, requiredDate);
//		slots = depotSlots.getDepotSlot();
//		return slots;
//
//	}
//
//	public void bookslot(int slotId) {
//
//		depotSlots.bookDepotSlot(slotId);
//		System.out.println("Slot Date" + "\t\t\t" + "Number of Slots" + "\t\t" + "Depot Id");
//		for (int slot = 0; slot < slots.size(); slot++) {
//			if (slots.get(slot).getNoOfSlot() > 0)
//				System.out.println(slots.get(slot).getStartTime() + " \t" + slots.get(slot).getNoOfSlot() + "\t\t\t"
//						+ slots.get(slot).getDcId());
//			else
//				slots.remove(slot);
//
//		}
//
//	}
//}
