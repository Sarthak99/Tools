package com.supplierbooking.services;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.supplierbooking.entities.ApptEntity;

import com.supplierbooking.repositories.ApptRepository;

@Service
public class AppointmentServiceImpl {

	@Autowired
	private ApptRepository appointmentRepository;

	public ApptEntity save(@Valid ApptEntity appointment1) {
		return appointmentRepository.save(appointment1);
	}

}
