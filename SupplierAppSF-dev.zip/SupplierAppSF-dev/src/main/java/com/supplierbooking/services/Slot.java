///*Class to define the entity slot having startTime,noOfSlot and dcId as arguments*/
//
//package com.supplierbooking.services;
//
//import java.util.Date;
//
//import org.springframework.stereotype.Component;
//
//import lombok.Data;
//
//@Component
//@Data
//public class Slot {
//
//	private Date startTime;
//	private int noOfSlot;
//
//	private int dcId;
//
//	@Override
//	public String toString() {
//		return "Slot [startTime=" + startTime + ", noOfSlot=" + noOfSlot + ", dcId=" + dcId + "]";
//	}
//
//	public Slot() {
//		super();
//	}
//
//	public Slot(Date startTime, int noOfSlot, int dcId) {
//
//		// System.out.println("Inside constructor of slot");
//		this.startTime = startTime;
//		this.noOfSlot = noOfSlot;
//		this.dcId = dcId;
//	}
//
////public Date getStartTime() {
////	return startTime;
////}
////
////public void setStartTime(Date startTime) {
////	this.startTime = startTime;
////}
////
////public int getNoOfSlot() {
////	return noOfSlot;
////}
////
////public void setNoOfSlot(int noOfSlot) {
////	this.noOfSlot = noOfSlot;
////}
////
////public int getDcId() {
////	return dcId;
////}
////
////public void setDcId(int dcId) {
////	this.dcId = dcId;
////}
//
//}
