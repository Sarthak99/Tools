package com.supplierbooking.services;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.supplierbooking.entities.ApptEntity;
import com.supplierbooking.repositories.ApptRepository;

@Service
public class ApptServiceImpl {

	@Autowired
	private ApptRepository apptRepository;

	public ApptEntity save(@Valid ApptEntity appointment1) {
		return apptRepository.save(appointment1);
	}

	public List<ApptEntity> findAppts() {
		return apptRepository.findAppt();
	}

	public String findApptref() {

		String apptRef;

		ApptEntity lastAppt = apptRepository.findApptref();

		if (lastAppt == null) {
			apptRef = "12345";
		} else {
			String temp = lastAppt.getApptRef();
			try {
				// the String to int conversion happens here
				int i = Integer.parseInt(temp.trim());

				// print out the value after the conversion
				i++;
				temp=Integer.toString(i);
				System.out.println(temp);
			} catch (NumberFormatException nfe) {
				System.out.println("NumberFormatException: " + nfe.getMessage());
			}

			apptRef =temp;
		}

		return apptRef;
	}

}
