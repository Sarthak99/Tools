//Class which implement the Slot Repository.

package com.supplierbooking.services;


import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.supplierbooking.entities.SlotEntity;
import com.supplierbooking.repositories.SlotRepository;

@Service
public class SlotServiceImpl{

	// Implementing an interface.
	@Autowired
	private SlotRepository slotRepository;
	
	private String temp="00:00:00";

	public SlotRepository getSlotRepository() {
		return slotRepository;
	}

	public void setSlotRepository(SlotRepository slotRepository) {
		this.slotRepository = slotRepository;
	}

	
	
	
	
	//Comparator ends.
	
	
	// This method used for saving the slot entry in the couch base database.
	public SlotEntity save(@Valid SlotEntity slot) {
		return slotRepository.save(slot);
	}

	// This method will return the slot based on depotid,countrycode and slot date
	public List<SlotEntity> findSlotByDepotIdCountryCodeSlotDate(String depotId, String countryCode, String slotDate) {
		slotDate=slotDate+temp;
		List<SlotEntity> tempList=slotRepository.findSlotByDepotIdCountryCodeSlotDate(depotId, countryCode, slotDate);
		
		return tempList;
	}

	// This Method for update of noOfslot when the supplier selects any particular
	// slot based on slot id.
	public void update(String slotId) {
		SlotEntity slotToUpdate = slotRepository.findById(slotId).orElse(null);
		slotToUpdate.setNoOfSlots(slotToUpdate.getNoOfSlots() - 1);
		if (slotToUpdate.getNoOfSlots() >= 0)
			slotRepository.save(slotToUpdate);
	}

	
	
}
