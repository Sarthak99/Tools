//Class which implement the Depot Repository.

package com.supplierbooking.services;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.supplierbooking.entities.DepotEntity;
import com.supplierbooking.repositories.DepotRepository;

@Service
public class DepotServiceImpl {

	@Autowired
	private DepotRepository depotRepository;

	// Method to save depot entity in the couch base data base.
	public DepotEntity save(@Valid DepotEntity depot) {
		return depotRepository.save(depot);
	}

	// Method to fetch list of depot based on country code.
	public List<DepotEntity> findByCountryCode(String countryCode) {
		return depotRepository.findByCountryCode(countryCode);
	}

}
