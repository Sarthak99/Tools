//Class which implement the Country Repository.

package com.supplierbooking.services;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.supplierbooking.entities.CountryEntity;
import com.supplierbooking.repositories.CountryRepository;

@Service
public class CountryServiceImpl {
	
	@Autowired
	private CountryRepository countryRepository;
	
	//This method will save the country entity in couch base db.
	public  CountryEntity save(@Valid CountryEntity country) {
		return countryRepository.save(country);
	}
	
	//This method will return the list of country stored.
	public List<CountryEntity>findCountry(){
		return countryRepository.findCountry();
	}
}
