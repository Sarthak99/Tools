package com.supplierbooking.services;

import com.supplierbooking.entities.POEntity;
//import com.supplierbooking.entities.Temp;
import com.supplierbooking.repositories.PORepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.validation.Valid;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;

@Service
public class POServiceImpl {
	@Autowired
	private PORepository poRepository;

	String temp = "00:00:00";
	String deliveryDateExact = "";
	String deliveryDatePlusOne = "";

	// This method will save the PO entity in couch base db.
	public POEntity save(@Valid POEntity po) {
		return poRepository.save(po);
	}

	// This method will return the list of PO stored.
	public List<POEntity> findPOs() {
		return poRepository.findPOs();
	}

	// Testing function for date
	private void dateConversion(String deliveryDate) {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = Calendar.getInstance();
		try {
			c.setTime(sdf.parse(deliveryDate));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		// Incrementing the date by 1 day
		c.add(Calendar.DAY_OF_MONTH, 1);
		deliveryDatePlusOne = sdf.format(c.getTime());

		// Converted to exact form to match in couchbase
		deliveryDateExact = deliveryDate;

	}
	// Testing function ends.

	// This method will fetch the list of POs based on countrycode,depotid,vendor
	// number and date.
	public List<POEntity> findPOsByVendor(String countryCode, String depotId, String vendor_NBR, String deliveryDate) {
		dateConversion(deliveryDate);
		System.out.println(
				"datafrom front end" + countryCode + depotId + vendor_NBR + deliveryDate + deliveryDatePlusOne);
		// System.out.println("Testing"+deliveryDateExact+deliveryDatePlusOne);
		List<POEntity> temp;
		List<POEntity> temp1 = new ArrayList<POEntity>();
		temp = poRepository.findPOsByVendor(countryCode, depotId, vendor_NBR, deliveryDate, deliveryDatePlusOne);
		int flag = 0;
		String poNumber;
		for (int i = 0; i < temp.size(); ++i) {
			poNumber = temp.get(i).getPoNbr();

			for (int j = 0; j < temp1.size(); ++j) {
				if (temp1.get(j).getPoNbr().equals(poNumber)) {
					flag = 1;
					break;
				}
			}
			if (flag == 0) {
				temp1.add(temp.get(i));
			}
			flag = 0;

		}
		return temp1;
	}

}
