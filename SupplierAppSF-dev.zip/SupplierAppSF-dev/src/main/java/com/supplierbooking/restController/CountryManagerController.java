//RestController class for exposing end point for country related information.

package com.supplierbooking.restController;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.supplierbooking.entities.CountryEntity;
import com.supplierbooking.services.CountryServiceImpl;

@RestController
@CrossOrigin("*")
public class CountryManagerController {
	
	static final Logger log4j = LogManager.getLogger(CountryManagerController.class);
	
	@Autowired
	private CountryServiceImpl countryServiceImpl;
	
	//This controller will return the list of country stored.
	@GetMapping(path="/countrylist")
	public ResponseEntity<List<CountryEntity>> findCountry(){
		ResponseEntity<List<CountryEntity>> responseBody=null;
		try {
			responseBody=new ResponseEntity<List<CountryEntity>>(countryServiceImpl.findCountry(),HttpStatus.ACCEPTED);
			log4j.info("Uri called for fetching list of country");
			return responseBody;
		}
		catch(Exception e) {
			responseBody=new ResponseEntity<List<CountryEntity>>(HttpStatus.INTERNAL_SERVER_ERROR);
			log4j.error("Error in fetching list of country");
			return responseBody;
		}
	}
}
