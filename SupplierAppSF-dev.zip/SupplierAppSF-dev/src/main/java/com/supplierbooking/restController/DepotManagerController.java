//RestController class for exposing end point for Depot related information.

package com.supplierbooking.restController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.supplierbooking.entities.DepotEntity;
import com.supplierbooking.services.DepotServiceImpl;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;

@RestController
@CrossOrigin("*")
public class DepotManagerController {

	static final Logger log4j = LogManager.getLogger(DepotManagerController.class);

	@Autowired
	private DepotServiceImpl depotServiceImpl;

	// This controller will return the list of depot based on countrycode with
	// endpoint as /depotlist.
	@PostMapping(path = "/depotlist")
	public ResponseEntity<List<DepotEntity>> listOfDepot(@RequestBody String countryCode) {
		ResponseEntity<List<DepotEntity>> responseBody = null;
		try {
			JSONObject jObject = new JSONObject(countryCode);
			String code = (String) jObject.get("countryCode");
			responseBody = new ResponseEntity<List<DepotEntity>>(depotServiceImpl.findByCountryCode(code),
					HttpStatus.ACCEPTED);
			log4j.info("Depot list found for country code");
			return responseBody;
		} catch (Exception e) {
			log4j.error("Problem in fetching list of depot based on country code");
			responseBody = new ResponseEntity<List<DepotEntity>>(HttpStatus.INTERNAL_SERVER_ERROR);
			return responseBody;
		}

	}
}
