package com.supplierbooking.restController;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

//import com.supplierbooking.Couchbase.Database;
import com.supplierbooking.entities.POEntity;
import com.supplierbooking.services.POServiceImpl;

@RestController
@CrossOrigin("*")
public class POManagerController {
    private static final Logger log4j = LogManager.getLogger(POManagerController.class);

    @Autowired
    private POServiceImpl poServiceImpl;

    @GetMapping(path="/purchase_orders")
    public ResponseEntity<List<POEntity>> findPOs() {
        ResponseEntity<List<POEntity>> responseBody;
        try {
            responseBody = new ResponseEntity<>(poServiceImpl.findPOs(), HttpStatus.ACCEPTED);
            System.out.println(responseBody);
            log4j.info("URI called for fetching list of purchase orders");
            return responseBody;
        } catch (Exception e) {
            System.out.println(e);
            responseBody = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            log4j.error("Error in fetching list of purchase orders");
            return responseBody;
        }
    }
    
    //This controller will return the list of Purchase Orders (POs) based on Vendor Number
    @GetMapping(path="/purchaseorder/vendorenumber")
    public ResponseEntity<List<POEntity>> findPOsByVendor(@RequestParam String countryCode,@RequestParam String depotId,@RequestParam String vendor_NBR,@RequestParam String deliveryDate) {
        ResponseEntity<List<POEntity>> responseBody=null;
        try {
        	System.out.println(countryCode+depotId+vendor_NBR+deliveryDate);
        	responseBody= new ResponseEntity<List<POEntity>>(poServiceImpl.findPOsByVendor(countryCode,depotId,vendor_NBR,deliveryDate), HttpStatus.ACCEPTED);
        	log4j.info("URI called for fetching POs based on vendor number");
        	return responseBody;
        	
        	
        }catch(Exception e) {
        	responseBody = new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
            log4j.error("Error in fetching list of purchase orders based on vendor number");
            return responseBody;
        }
        
    }
    


}
