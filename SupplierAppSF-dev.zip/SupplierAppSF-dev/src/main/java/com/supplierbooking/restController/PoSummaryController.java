package com.supplierbooking.restController;

import java.util.List;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.supplierbooking.entities.PoSummaryMappingWithDepotIdEnity;
import com.supplierbooking.services.PoSummaryServiceImpl;

@RestController
@CrossOrigin("*")
public class PoSummaryController {

	// log4j used for logging the logs for an application.
	static final Logger log4j = LogManager.getLogger(PoSummaryController.class);

	@Autowired
	private PoSummaryServiceImpl poSummaryServiceImpl;

	@RequestMapping(value = "/getposummary", method = RequestMethod.GET)
	public List<PoSummaryMappingWithDepotIdEnity> getPoSummaryByUserId(@RequestParam String type,
			@RequestParam String userId) {
		try {
			log4j.info("Controller called for fetching PoSummary");
			return poSummaryServiceImpl.getPoSummaryByUserId(type, userId);
		} catch (Exception e) {
			log4j.error("Error in Controller Fetching PoSummary");
			return null;
		}

	}
}
