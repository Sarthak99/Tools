package com.supplierbooking.restController;

import javax.servlet.http.HttpServletRequest;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;



@Controller
@CrossOrigin("*")
public class MyCustomErrorController implements ErrorController {

	  @RequestMapping("/error")
	  @ResponseBody
	  public String handleError(HttpServletRequest request) {
		  System.out.println("check\n"+request.getAttribute("javax.servlet.error.message")+"\n");
		  System.out.println("check\n"+request.getAttribute("javax.servlet.error.request_uri")+"\n");
	      Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
	      Exception exception = (Exception) request.getAttribute("javax.servlet.error.exception");
	      return String.format("<html><body><h2>Error Page</h2><div>Status code: <b>%s</b></div>"
	                      + "<div>Exception Message: <b>%s</b></div><body></html>",
	              statusCode, exception==null? "N/A": exception.getMessage());
	  }

	  @Override
	  public String getErrorPath() {
	      return "/error";
	  }
	}