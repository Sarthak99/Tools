//RestController class for exposing end point for Slot related information.

package com.supplierbooking.restController;

import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.couchbase.client.java.error.DocumentAlreadyExistsException;
import com.supplierbooking.entities.SlotEntity;
import com.supplierbooking.services.SlotServiceImpl;

@RestController
@CrossOrigin("*")
public class SlotManagerController {

	// log4j used for logging the logs for an application.
	static final Logger log4j = LogManager.getLogger(SlotManagerController.class);

	// Creating an instance of a class SlotServiceImpl.
	@Autowired
	private SlotServiceImpl slotServiceImpl;

	// This controller will return the list of slot based on depotId,countryCode and
	// date for which supplier wish to book a slot.
	@PostMapping(path = "/depotId/countryCode/slotDate")
	public ResponseEntity<List<SlotEntity>> getSlotByDepotCountryAndDate(@RequestBody String depotCountryDate) {
		ResponseEntity<List<SlotEntity>> responseBody = null;
		try{JSONObject jObject = new JSONObject(depotCountryDate);
			String depotId = (String) jObject.get("depotId");
			String countryCode = (String) jObject.get("countryCode");
			String slotDate = (String) jObject.get("slotDate");
		
			log4j.info("Slot Fetching Api is called");
			List<SlotEntity> list = slotServiceImpl.findSlotByDepotIdCountryCodeSlotDate(depotId, countryCode,
					slotDate);
			responseBody = new ResponseEntity<List<SlotEntity>>(list, HttpStatus.ACCEPTED);
			return responseBody;
		} catch (Exception e) {
			log4j.error("Error in Fetching the slot");
			return responseBody;

		}
	}

	// This controller will update the noOfSlot based on slot id and delete the slot
	// if noOfSlot become zero.
	@PutMapping("/slotupdate")
	public ResponseEntity<String> slotUpdate(@RequestBody String slotIdDetails) {
		ResponseEntity<String> responsebody = null;
		JSONObject jObject = new JSONObject(slotIdDetails);
		String slotId = (String) jObject.get("slotId");
		try {
			log4j.info("Slot Info updated based on slot id");
			responsebody = new ResponseEntity<String>("OK", HttpStatus.ACCEPTED);
			slotServiceImpl.update(slotId);

		} catch (NullPointerException e) {
			responsebody = new ResponseEntity<String>("Error", HttpStatus.INTERNAL_SERVER_ERROR);
			log4j.error("Slot Id doesn't exist");

		}
		return responsebody;

	}

	// This controller will Create the new slot in the couchbase
	@PostMapping("/slotcreate")
	public String slotCreate(@RequestParam String slotId, @RequestParam String depotId,
			@RequestParam String countryCode, @RequestParam int noOfSlots, @RequestParam String slotDate,
			@RequestParam String slotTime, @RequestParam String type) {
		try {
			slotServiceImpl.save(new SlotEntity(slotId, depotId, countryCode, noOfSlots, slotDate, slotTime, type));
			return "Inserted";
		} catch (DocumentAlreadyExistsException e) {
			return e.getMessage();
			// return "Error";

		}
	}

	// Base Controller just for testing
	@GetMapping("/")
	public String Base() {
		log4j.info("Base Uri is called");
		return "Welcome";
	}

	// Commented method
	// @GetMapping("/noofslot")
	// @ResponseBody
	// public long countSlot(@RequestParam String type) {
	// return slotServiceImpl.countSlot(type);
	// }
}
