//package com.supplierbooking.runner;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import com.supplierbooking.entities.DepotEntity;
////import com.supplierbooking.entities.CountryEntity;
//import com.supplierbooking.entities.SlotEntity;
//import com.supplierbooking.services.DepotServiceImpl;
////import com.supplierbooking.services.CountryServiceImpl;
//import com.supplierbooking.services.SlotServiceImpl;
//
//@Component
//public class SlotCreation {
//	
//	@Autowired
//	private SlotServiceImpl slotServiceImpl;
//	
//	@Autowired
//	private DepotServiceImpl depotServiceImpl;
//	
//	
//	public void depotCreate() {
//		DepotEntity depot1=new DepotEntity("TH901","TH","901","Thfrsh","Depot");
//		depotServiceImpl.save(depot1);
//	}
//	
//	public void slotCreate(String slotId,int depotId,String countryCode,int noOfSlots,
//							String slotDate,String slotTime,String type) {
//		SlotEntity slot1=new SlotEntity(slotId,depotId,countryCode,noOfSlots,slotDate,slotTime,type);
//		slotServiceImpl.save(slot1);
//		
//	}
//	public void slotfind() {
//		System.out.println("slot"+slotServiceImpl.findById("S_01"));
//	}
//	
//	public void findByDepotIdAndCountryCode() {
//		System.out.println("slots"+slotServiceImpl.findByDepotIdAndCountryCode(901,"ML"));
//	}
//	
//	public void findSlotByDepotIdCountryCodeSlotDate() {
//		System.out.println("slots"+slotServiceImpl.findSlotByDepotIdCountryCodeSlotDate(901,"ML","04/03/2020"));
//	}
//	
//	public void countSlot() {
//		System.out.println(slotServiceImpl.countSlot("Slot"));
//	}
//	public void updateSlot() {
//		slotServiceImpl.update("S_01");
//	}
//	
//}
