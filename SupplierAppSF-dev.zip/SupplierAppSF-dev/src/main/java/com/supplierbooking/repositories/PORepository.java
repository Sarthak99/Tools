package com.supplierbooking.repositories;

import com.supplierbooking.entities.POEntity;
//import com.supplierbooking.entities.Temp;


import org.springframework.data.couchbase.core.query.N1qlPrimaryIndexed;
import org.springframework.data.couchbase.core.query.Query;
import org.springframework.data.couchbase.core.query.ViewIndexed;
import org.springframework.data.couchbase.repository.CouchbasePagingAndSortingRepository;


import java.util.List;

@N1qlPrimaryIndexed
@ViewIndexed(designDoc = "POEntity")
public interface PORepository extends CouchbasePagingAndSortingRepository<POEntity, String> {
    
	@Query("SELECT a1.poNbr, a1.poDate, a1.deliveryDate, a1.buyerDetails, a1.totalCases, a2.apptNbr, a2.apptEndTs, META(a1).id as _ID, META(a1).cas as _CAS " +
            "FROM `Order_data` a1 " +
            "JOIN `Order_data` a2 ON KEYS a1.apptNumber ")
    List<POEntity> findPOs();
	
	//and (DELIV_NOT_BEFORE_DATE=$4 or DELIV_NOT_BEFORE_DATE=$5)
    
    @Query("#{#n1ql.selectEntity} where #{#n1ql.filter} and country=$1 and SUBSTR(siteDetails,1) = $2 and"
    		+ " supplierNo=$3 and (deliveryDate=$4 or deliveryDate=$5) and type='PO' ORDER BY deliveryDate")
    List<POEntity> findPOsByVendor(String countryCode, String depotId, String vendor_NBR, String deliveryDate,String deliveryDatePlusOne);
    

//    //@Query("SELECT COUNT(*) FROM #{#n1ql.bucket} WHERE #{#n1ql.filter} and type = 'PO' GROUP BY 'VENDOR_NBR'")

////    @Query("SELECT VENDOR_NBR  FROM #{#n1ql.bucket} WHERE #{#n1ql.filter} and type = 'PO'")
////    List<Temp> findCount();

}



///String vendor_NBR,String bookDate, String newDate, String deliveryDateExact, String deliveryDatePlusOne);


//siteDetails,META().id,META().cas