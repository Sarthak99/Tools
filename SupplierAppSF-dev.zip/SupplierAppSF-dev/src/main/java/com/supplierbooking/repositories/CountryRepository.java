//Interface to define query or extend the query provided by couch base db for country entity.

package com.supplierbooking.repositories;

import java.util.List;

import org.springframework.data.couchbase.core.query.N1qlPrimaryIndexed;
import org.springframework.data.couchbase.core.query.Query;
import org.springframework.data.couchbase.core.query.ViewIndexed;
import org.springframework.data.couchbase.repository.CouchbasePagingAndSortingRepository;

import com.supplierbooking.entities.CountryEntity;


@N1qlPrimaryIndexed
@ViewIndexed(designDoc = "countryEntity")
public interface CountryRepository extends CouchbasePagingAndSortingRepository<CountryEntity, String> {
	
	//This query will return the list of country stored.
	@Query("#{#n1ql.selectEntity} where #{#n1ql.filter} and type='Country'")
	List<CountryEntity> findCountry();

}
