//Interface to define query or extend the query provided by couch base db for Depot entity.

package com.supplierbooking.repositories;

import java.util.List;

import org.springframework.data.couchbase.core.query.Query;
import org.springframework.data.couchbase.repository.CouchbasePagingAndSortingRepository;

import com.supplierbooking.entities.DepotEntity;

public interface DepotRepository extends CouchbasePagingAndSortingRepository<DepotEntity, String> {

	// Query to fetch list of depot based on country code.
	@Query("#{#n1ql.selectEntity} where #{#n1ql.filter} and countryCode = $1 and type='Depot'")
	List<DepotEntity> findByCountryCode(String countryCode);
}
