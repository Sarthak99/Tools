//Interface to define query or extend the query provided by couch base db for slot entity.

package com.supplierbooking.repositories;

import java.util.List;

import org.springframework.data.couchbase.core.query.N1qlPrimaryIndexed;
import org.springframework.data.couchbase.core.query.Query;
import org.springframework.data.couchbase.core.query.ViewIndexed;
import org.springframework.data.couchbase.repository.CouchbasePagingAndSortingRepository;

import com.supplierbooking.entities.SlotEntity;

@N1qlPrimaryIndexed
@ViewIndexed(designDoc = "slot")
public interface SlotRepository extends CouchbasePagingAndSortingRepository<SlotEntity, String> {
	
	//Query for fetching list of slot from the couch base based on depotid, countrycode and date. 
	@Query("#{#n1ql.selectEntity} where #{#n1ql.filter} and depotId = $1 and countryCode = $2 and slotDate= $3 and noOfSlots>0 and type='Slot' ORDER BY slotTime")
	List<SlotEntity> findSlotByDepotIdCountryCodeSlotDate(String depotId,String countryCode,String slotDate);
	
	
//	@Query("#{#n1ql.selectEntity} where #{#n1ql.filter} and depotId = $1 and countryCode = $2")
//	List<SlotEntity> findByDepotIdAndCountryCode(int depotId,String countryCode);
//	
//	
//	@Query("SELECT COUNT(*) AS count FROM #{#n1ql.bucket} WHERE #{#n1ql.filter} and type = 'Slot'")
//    Long countSlot(String type);
}
