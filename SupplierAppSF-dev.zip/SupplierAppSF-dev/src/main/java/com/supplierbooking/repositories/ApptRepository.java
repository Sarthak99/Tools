package com.supplierbooking.repositories;

import java.util.List;

import org.springframework.data.couchbase.core.query.N1qlPrimaryIndexed;
import org.springframework.data.couchbase.core.query.Query;
import org.springframework.data.couchbase.core.query.ViewIndexed;
import org.springframework.data.couchbase.repository.CouchbasePagingAndSortingRepository;

import com.supplierbooking.entities.ApptEntity;


@N1qlPrimaryIndexed
@ViewIndexed(designDoc = "ApptEntity")
public interface ApptRepository  extends CouchbasePagingAndSortingRepository<ApptEntity, String>{
	
	@Query("#{#n1ql.selectEntity} where #{#n1ql.filter} and type='Appointment'")
    List<ApptEntity> findAppt();
	
	
	//Query to find last appointment number from couchbase
	@Query("#{#n1ql.selectEntity} where #{#n1ql.filter} and type='Appointment' Order by apptRef desc limit 1")
	ApptEntity findApptref();
	
	// N1qlQuery airlineQuery = N1qlQuery.simple("SELECT `travel-sample`.* FROM `travel-sample` WHERE name=\"United Airlines\" AND type=\"airline\"");
	
}
